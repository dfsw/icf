//
//  PHGCustomSectionHeader.h
//  PhotoGallery
//
//  Created by Joe Keeley on 7/21/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGCustomSectionHeader : UICollectionReusableView

@property (nonatomic, retain) IBOutlet UILabel *headerLabel;

@end

//
//  PHGThumbCell.h
//  PhotoGallery
//
//  Created by Joe Keeley on 6/9/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGThumbCell : UICollectionViewCell

@property (nonatomic, strong) IBOutlet UIImageView *thumbImageView;

@end

//
//  PHGMasterViewController.m
//  PhotoGallery
//
//  Created by Joe Keeley on 6/4/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import "PHGMasterViewController.h"

@implementation PHGMasterViewController

@end

//
//  PHGSectionDecorationTopView.h
//  PhotoGallery
//
//  Created by Joe Keeley on 7/20/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGSectionDecorationTopView : UICollectionReusableView

@end

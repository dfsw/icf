//
//  UIViewController+ICFViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 11/2/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "UIViewController+ICFViewController.h"

@implementation UIViewController (ICFViewController)

#pragma mark - Alert
- (void)presentAlertWithMessage:(NSString *)message {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"Alert"
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *dismissAction =
    [UIAlertAction actionWithTitle:@"OK"
                             style:UIAlertActionStyleCancel
                           handler:^(UIAlertAction *action){
                               [self dismissViewControllerAnimated:YES completion:nil];
                           }];
    
    [alert addAction:dismissAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

@end

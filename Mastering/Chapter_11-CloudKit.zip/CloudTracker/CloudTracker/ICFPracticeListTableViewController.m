//
//  ICFPracticeListTableViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFPracticeListTableViewController.h"
#import "ICFPracticeTableViewCell.h"
#import "ICFPracticeDetailViewController.h"
#import "UIViewController+ICFViewController.h"

@interface ICFPracticeListTableViewController ()
@property (nonatomic, strong) NSMutableArray *runList;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addPracticeRunButton;
@end

@implementation ICFPracticeListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[CKContainer defaultContainer] accountStatusWithCompletionHandler:^(CKAccountStatus accountStatus, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [self.addPracticeRunButton setEnabled:(accountStatus == CKAccountStatusAvailable)];
            if (accountStatus == CKAccountStatusAvailable) {
                [self loadRunsFromCloudKit];
            } else {
                [self presentAlertWithMessage:@"Please connect to an iCloud account to manage practice runs."];
            }
        });

    }];
}

- (void)loadRunsFromCloudKit {
    CKDatabase *privateDatabase = [[CKContainer defaultContainer] privateCloudDatabase];
    
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"TRUEPREDICATE"];
    CKQuery *query = [[CKQuery alloc] initWithRecordType:@"PracticeRun" predicate:predicate];
    
    __weak ICFPracticeListTableViewController *weakSelf = self;
    
    [privateDatabase performQuery:query
                     inZoneWithID:nil
                completionHandler:^(NSArray *results, NSError *error) {
                    dispatch_async(dispatch_get_main_queue(), ^{
                        if (error.code == CKErrorNotAuthenticated) {
                            [weakSelf presentAlertWithMessage:@"Not authenticated with iCloud - cannot display private iCloud database info."];
                        }
                        
                        weakSelf.runList = [[NSMutableArray alloc] initWithArray:results];
                        [weakSelf.tableView reloadData];
                    });
                }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.runList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ICFPracticeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"runListCell" forIndexPath:indexPath];
    
    CKRecord *run = self.runList[indexPath.row];
    
    NSString *practiceTypeAndDist = [NSString stringWithFormat:@"%@ - %.2f %@", run[@"practiceType"],[run[@"distance"] doubleValue],run[@"distanceUnits"]];
    [cell.practiceLabel setText:practiceTypeAndDist];
    
    NSString *runTime = [NSString stringWithFormat:@"%02d:%02d:%02d",[run[@"hours"] integerValue],[run[@"minutes"] integerValue],[run[@"seconds"] integerValue]];
    [cell.timeLabel setText:runTime];
    
    return cell;
}


- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        CKRecord *practiceRun = self.runList[indexPath.row];
        CKDatabase *privateDatabase = [[CKContainer defaultContainer] privateCloudDatabase];

        [self.runList removeObject:practiceRun];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

        //__weak ICFPracticeListTableViewController *weakSelf = self;
        [privateDatabase deleteRecordWithID:practiceRun.recordID completionHandler:^(CKRecordID *recordID, NSError *error) {
            if (error) {
                NSLog(@"Delete failed: %@", error.localizedDescription);
            } else {
                NSLog(@"Practice run deleted.");
            }
        }];
        
    }
}

#pragma mark - ICFRunDataProtocol
- (void)runAdded:(CKRecord *)run {
    [self.runList addObject:run];
    [self.tableView reloadData];
}

- (void)runUpdated:(CKRecord *)run forIndexPath:(NSIndexPath *)indexPath {
    [self.runList replaceObjectAtIndex:indexPath.row withObject:run];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ICFPracticeDetailViewController *detail = (ICFPracticeDetailViewController *)segue.destinationViewController;
    [detail setRunDataDelegate:self];
    if ([segue.identifier isEqualToString:@"addPracticeRun"]) {
        [detail setIndexPathForRun:nil];
    }
    if ([segue.identifier isEqualToString:@"updatePracticeRun"]) {
        NSIndexPath *tappedRowIndexPath = [self.tableView indexPathForSelectedRow];
        CKRecord *runData = [self.runList objectAtIndex:tappedRowIndexPath.row];
        [detail setIndexPathForRun:tappedRowIndexPath];
        [detail setRunData:runData];
    }
}


@end

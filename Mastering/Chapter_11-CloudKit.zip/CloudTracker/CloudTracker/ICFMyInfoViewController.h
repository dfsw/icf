//
//  ICFMyInfoViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CloudKit;

@interface ICFMyInfoViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *name;
@property (weak, nonatomic) IBOutlet UITextField *location;
- (IBAction)cancelButtonTapped:(id)sender;
- (IBAction)saveButtonTapped:(id)sender;
@end

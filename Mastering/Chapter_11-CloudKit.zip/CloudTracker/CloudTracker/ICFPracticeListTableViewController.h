//
//  ICFPracticeListTableViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CloudKit;

@protocol ICFRunDataProtocol <NSObject>

- (void)runAdded:(CKRecord *)run;
- (void)runUpdated:(CKRecord *)run forIndexPath:(NSIndexPath *)indexPath;

@end

@interface ICFPracticeListTableViewController : UITableViewController <ICFRunDataProtocol>

@end

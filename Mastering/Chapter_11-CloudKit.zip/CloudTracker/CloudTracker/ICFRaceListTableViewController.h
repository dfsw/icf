//
//  ICFRaceListTableViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import CloudKit;

@protocol ICFRaceDataProtocol <NSObject>

- (void)raceAdded:(CKRecord *)race;
- (void)raceUpdated:(CKRecord *)race forIndexPath:(NSIndexPath *)indexPath;

@end


@interface ICFRaceListTableViewController : UITableViewController <ICFRaceDataProtocol>

@end

//
//  ICFMyInfoViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFMyInfoViewController.h"
#import "UIViewController+ICFViewController.h"
#import "AppDelegate.h"

@interface ICFMyInfoViewController ()

@property (nonatomic, strong) NSDictionary *currentUserInfo;
@property (nonatomic, strong) NSString *myUserRecordName;
@property (nonatomic, strong) CKRecord *myUserRecord;

@end

@implementation ICFMyInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.currentUserInfo = [defaults objectForKey:@"currentUserInfo"];
    if (!self.currentUserInfo) {
        self.currentUserInfo = @{@"name":@"",@"location":@"",@"recordName":@""};
    }
    [self.name setText:self.currentUserInfo[@"name"]];
    [self.location setText:self.currentUserInfo[@"location"]];
    self.myUserRecordName = self.currentUserInfo[@"recordName"];
}

- (void)viewDidAppear:(BOOL)animated {
    [[CKContainer defaultContainer] requestApplicationPermission:CKApplicationPermissionUserDiscoverability
     completionHandler:^(CKApplicationPermissionStatus applicationPermissionStatus, NSError *error) {
        if (error)
        {
            NSLog(@"Uh oh - error requesting discoverability permission: %@",error.localizedDescription);
        } else
        {
            if (applicationPermissionStatus == CKApplicationPermissionStatusGranted)
            {
                [self lookUpUserInfo];
            }
        }
    }];
}

- (void)discoverUserInfoForRecordID:(CKRecordID *)recordID {
    [[CKContainer defaultContainer] discoverAllContactUserInfosWithCompletionHandler:
     ^(NSArray *userInfos, NSError *error) {
         if (error)
         {
             NSLog(@"Error discovering contacts: %@",error.localizedDescription);
         } else
         {
             NSLog(@"Got info: %@", userInfos);
             
             for (CKDiscoveredUserInfo *info in userInfos) {
                 if ([info.userRecordID.recordName isEqualToString:recordID.recordName]) {
                     //this is the current user's record
                     dispatch_async(dispatch_get_main_queue(), ^{
                         NSString *myName = [NSString stringWithFormat:
                                             @"%@ %@",info.firstName, info.lastName];
                         
                         [self.name setText:myName];
                         self.myUserRecordName = info.userRecordID.recordName;
                         
                         self.currentUserInfo = @{@"name":myName,
                                                  @"location":self.location.text,
                                                  @"recordName":info.userRecordID.recordName};
                         
                         NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                         [defaults setObject:self.currentUserInfo forKey:@"currentUserInfo"];
                         [defaults synchronize];
                         
                         [self fetchMyUserRecord];
                     });
                 }
             }
         }
     }];
}

- (void)lookUpUserInfo {
    [[CKContainer defaultContainer] fetchUserRecordIDWithCompletionHandler:
     ^(CKRecordID *recordID, NSError *error) {
         if (error)
         {
             NSLog(@"Error fetching user record ID: %@",error.localizedDescription);
         } else
         {
             [self discoverUserInfoForRecordID:recordID];
         }
    }];
}

- (void)fetchMyUserRecord {
    if (self.myUserRecordName) {
        
        CKRecordID *myUserRecordID =
        [[CKRecordID alloc] initWithRecordName:self.myUserRecordName];

        CKDatabase *publicDatabase = [[CKContainer defaultContainer] publicCloudDatabase];
        [publicDatabase fetchRecordWithID:myUserRecordID
                        completionHandler:^(CKRecord *record, NSError *error) {
            if (error)
            {
                NSLog(@"Error fetching user record: %@", error.localizedDescription);
                [self setMyUserRecord:nil];
            } else
            {
                AppDelegate *appDelegate =
                (AppDelegate *)[[UIApplication sharedApplication] delegate];
                
                [appDelegate setMyUserRecord:record];
                [self setMyUserRecord:record];
            }
        }];
    }
}

- (IBAction)cancelButtonTapped:(id)sender {
    [self.name setText:self.currentUserInfo[@"name"]];
    [self.location setText:self.currentUserInfo[@"location"]];
}

- (IBAction)saveButtonTapped:(id)sender {
    self.currentUserInfo = @{@"name":self.name.text,
                             @"location":self.location.text,
                             @"recordName":self.myUserRecordName};
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:self.currentUserInfo forKey:@"currentUserInfo"];
    [defaults synchronize];
    
    if (self.myUserRecord) {
        self.myUserRecord[@"location"] = self.location.text;
        self.myUserRecord[@"name"] = self.name.text;
        CKDatabase *publicDatabase = [[CKContainer defaultContainer] publicCloudDatabase];
        [publicDatabase saveRecord:self.myUserRecord
                 completionHandler:^(CKRecord *record, NSError *error) {
            if (error) {
                NSLog(@"Error saving my user record: %@", error.localizedDescription);
            }
        }];
    }
}

@end

//
//  ICFRaceDetailViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICFRaceListTableViewController.h"
@import CloudKit;

@interface ICFRaceDetailViewController : UIViewController

- (IBAction)cancelButtonTapped:(id)sender;
- (IBAction)saveButtonTapped:(id)sender;

@property (weak, nonatomic) id<ICFRaceDataProtocol> raceDataDelegate;
@property (strong, nonatomic) NSIndexPath *indexPathForRace;
@property (strong, nonatomic) CKRecord *raceData;
@property (nonatomic) BOOL connectedToiCloud;

@property (weak, nonatomic) IBOutlet UITextField *raceName;
@property (weak, nonatomic) IBOutlet UITextField *location;
@property (weak, nonatomic) IBOutlet UITextField *distance;
@property (weak, nonatomic) IBOutlet UISegmentedControl *distanceUnit;
@property (weak, nonatomic) IBOutlet UITextField *hours;
@property (weak, nonatomic) IBOutlet UITextField *minutes;
@property (weak, nonatomic) IBOutlet UITextField *seconds;
@property (weak, nonatomic) IBOutlet UIDatePicker *datePicker;

@property (weak, nonatomic) IBOutlet UIBarButtonItem *raceCancelButton;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *raceSaveButton;
@property (weak, nonatomic) IBOutlet UIView *saveRaceActivityIndicator;
@end

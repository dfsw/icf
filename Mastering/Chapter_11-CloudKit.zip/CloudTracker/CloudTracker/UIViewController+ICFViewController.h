//
//  UIViewController+ICFViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 11/2/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (ICFViewController)
- (void)presentAlertWithMessage:(NSString *)message;
@end

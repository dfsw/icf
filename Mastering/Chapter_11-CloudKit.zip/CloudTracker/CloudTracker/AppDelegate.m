//
//  AppDelegate.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/11/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "AppDelegate.h"
#import <CloudKit/CloudKit.h>

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [application registerForRemoteNotifications];
    
    UIUserNotificationSettings *notifSettings =
    [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert |
     UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];

    [application registerUserNotificationSettings:notifSettings];

    return YES;
}

- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    NSLog(@"Registered for notifications: %@",deviceToken);
    
    CKDatabase *publicDatabase = [[CKContainer defaultContainer] publicCloudDatabase];
    NSPredicate *allRacesPredicate = [NSPredicate predicateWithFormat:@"TRUEPREDICATE"];
    NSString *subscriptionIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];

    CKSubscription *raceSubscription =
    [[CKSubscription alloc] initWithRecordType:@"Race"
                                     predicate:allRacesPredicate
                                subscriptionID:subscriptionIdentifier
                                       options:CKSubscriptionOptionsFiresOnRecordCreation |
                                               CKSubscriptionOptionsFiresOnRecordUpdate];
    
    CKNotificationInfo *notificationInfo = [[CKNotificationInfo alloc] init];
    [notificationInfo setAlertBody:@"New race info available!"];
    [raceSubscription setNotificationInfo:notificationInfo];
    
    [publicDatabase saveSubscription:raceSubscription
                   completionHandler:^(CKSubscription *subscription, NSError *error) {
        if (error)
        {
            NSLog(@"Could not subscribe for notifications: %@",error.localizedDescription);
        } else
        {
            NSLog(@"Subscribed for notifications");
        }
    }];
}

- (void)application:(UIApplication *)application
didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Error in push registration: %@", error.localizedDescription);
}

- (void)application:(UIApplication *)application
didReceiveRemoteNotification:(NSDictionary *)userInfo {
    NSString *message =
    [[[userInfo objectForKey:@"aps"] objectForKey:@"alert"] objectForKey:@"body"];
    
    NSString *appState = ([application applicationState] == UIApplicationStateActive) ?
    @"app Active" : @"app in Background";
    
    NSLog(@"Received remote push for app state %@: %@", appState, message);
}

@end

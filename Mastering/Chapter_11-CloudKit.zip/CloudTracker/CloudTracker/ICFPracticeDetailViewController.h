//
//  ICFPracticeDetailViewController.h
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICFPracticeListTableViewController.h"
@import CloudKit;

@interface ICFPracticeDetailViewController : UIViewController

- (IBAction)cancelButtonTapped:(id)sender;
- (IBAction)saveButtonTapped:(id)sender;

@property (weak, nonatomic) id<ICFRunDataProtocol> runDataDelegate;
@property (strong, nonatomic) NSIndexPath *indexPathForRun;
@property (strong, nonatomic) CKRecord *runData;

@property (weak, nonatomic) IBOutlet UITextField *practiceType;
@property (weak, nonatomic) IBOutlet UITextField *location;
@property (weak, nonatomic) IBOutlet UITextField *distance;
@property (weak, nonatomic) IBOutlet UISegmentedControl *distanceUnits;
@property (weak, nonatomic) IBOutlet UITextField *hours;
@property (weak, nonatomic) IBOutlet UITextField *minutes;
@property (weak, nonatomic) IBOutlet UITextField *seconds;
@property (weak, nonatomic) IBOutlet UIDatePicker *practiceRunDate;
@property (weak, nonatomic) IBOutlet UIView *practiceRunSaveIndicator;

@end

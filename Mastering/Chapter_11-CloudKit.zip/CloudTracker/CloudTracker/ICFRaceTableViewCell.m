//
//  ICFRaceTableViewCell.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFRaceTableViewCell.h"

@implementation ICFRaceTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

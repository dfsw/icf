//
//  ICFRaceListTableViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFRaceListTableViewController.h"
#import "ICFRaceTableViewCell.h"
#import "ICFRaceDetailViewController.h"

@interface ICFRaceListTableViewController ()
@property (nonatomic, strong) NSMutableArray *raceList;
@property (nonatomic) BOOL connectedToiCloud;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addRaceButton;
@end

@implementation ICFRaceListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [[CKContainer defaultContainer] accountStatusWithCompletionHandler:
     ^(CKAccountStatus accountStatus, NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.connectedToiCloud = (accountStatus == CKAccountStatusAvailable);
            [self.addRaceButton setEnabled:self.connectedToiCloud];
        });
    }];
    
    [self loadRacesFromCloudKit];
}

- (void)loadRacesFromCloudKit {
    CKDatabase *publicDatabase = [[CKContainer defaultContainer] publicCloudDatabase];
        
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"TRUEPREDICATE"];
    CKQuery *query = [[CKQuery alloc] initWithRecordType:@"Race" predicate:predicate];
        
    __weak ICFRaceListTableViewController *weakSelf = self;

    [publicDatabase performQuery:query
                    inZoneWithID:nil
               completionHandler:^(NSArray *results, NSError *error) {
                   dispatch_async(dispatch_get_main_queue(), ^{
                       weakSelf.raceList = [[NSMutableArray alloc] initWithArray:results];
                       [weakSelf.tableView reloadData];
                   });
               }];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.raceList.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ICFRaceTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"raceListCell" forIndexPath:indexPath];
    
    CKRecord *raceRecord = self.raceList[indexPath.row];
    
    [cell.nameLabel setText:raceRecord[@"racerName"]];
    NSString *raceNameAndDist = [NSString stringWithFormat:@"%@ %.2f %@", raceRecord[@"raceName"],[raceRecord[@"distance"] doubleValue],raceRecord[@"distanceUnits"]];
    [cell.raceNameLabel setText:raceNameAndDist];
    NSString *raceTime = [NSString stringWithFormat:@"%02d:%02d:%02d",[raceRecord[@"hours"] integerValue],[raceRecord[@"minutes"] integerValue],[raceRecord[@"seconds"] integerValue]];
    [cell.timeLabel setText:raceTime];
    
    return cell;
}

#pragma mark - Race Data Protocol
- (void)raceAdded:(CKRecord *)race {
    [self.raceList addObject:race];
    [self.tableView reloadData];
}

- (void)raceUpdated:(CKRecord *)race forIndexPath:(NSIndexPath *)indexPath {
    [self.raceList replaceObjectAtIndex:indexPath.row withObject:race];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ICFRaceDetailViewController *detail = (ICFRaceDetailViewController *)segue.destinationViewController;
    [detail setRaceDataDelegate:self];
    if ([segue.identifier isEqualToString:@"addRaceSegue"]) {
        [detail setIndexPathForRace:nil];
        [detail setConnectedToiCloud:self.connectedToiCloud];
    }
    if ([segue.identifier isEqualToString:@"updateRaceDetail"]) {
        NSIndexPath *tappedRowIndexPath = [self.tableView indexPathForSelectedRow];
        CKRecord *raceData = [self.raceList objectAtIndex:tappedRowIndexPath.row];
        [detail setIndexPathForRace:tappedRowIndexPath];
        [detail setRaceData:raceData];
        [detail setConnectedToiCloud:self.connectedToiCloud];
    }
}

@end

//
//  ICFPracticeDetailViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFPracticeDetailViewController.h"

@interface ICFPracticeDetailViewController ()

@end

@implementation ICFPracticeDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [self populateUIFromRunRecord:self.runData];
}

- (NSString *)selectedDistanceUnits {
    NSString *distanceUnitString = @"";
    switch (self.distanceUnits.selectedSegmentIndex) {
        case 0:
            distanceUnitString = @"Miles";
            break;
        case 1:
            distanceUnitString = @"Kilometers";
            break;
        case 2:
            distanceUnitString = @"Meters";
            break;
            
        default:
            break;
    }
    return distanceUnitString;
}

- (NSInteger)segmentForDistanceUnitString:(NSString *)unitString {
    NSInteger index = 0;
    if ([unitString isEqualToString:@"Miles"]) {
        index = 0;
    }
    if ([unitString isEqualToString:@"Kilometers"]) {
        index = 1;
    }
    if ([unitString isEqualToString:@"Meters"]) {
        index = 2;
    }
    return index;
}

- (void)updateRunFromUI {
    
    if (!self.runData) {
        self.runData = [[CKRecord alloc] initWithRecordType:@"PracticeRun"];
    }
    
    self.runData[@"practiceType"] = self.practiceType.text;
    self.runData[@"location"] = self.location.text;
    self.runData[@"distance"] = [NSNumber numberWithFloat:[self.distance.text floatValue]];
    self.runData[@"distanceUnits"] = [self selectedDistanceUnits];
    self.runData[@"hours"] = [NSNumber numberWithInteger:[self.hours.text integerValue]];
    self.runData[@"minutes"] = [NSNumber numberWithInteger:[self.minutes.text integerValue]];
    self.runData[@"seconds"] = [NSNumber numberWithInteger:[self.seconds.text integerValue]];
    self.runData[@"practiceRunDate"] = [self.practiceRunDate date];
}

- (void)populateUIFromRunRecord:(CKRecord *)run {
    if (!run) {
        return;
    }
    [self.practiceType setText:run[@"practiceType"]];
    [self.location setText:run[@"location"]];
    [self.distance setText:[run[@"distance"] stringValue]];
    [self.distanceUnits setSelectedSegmentIndex:[self segmentForDistanceUnitString:run[@"distanceUnits"]]];
    [self.hours setText:[run[@"hours"] stringValue]];
    [self.minutes setText:[run[@"minutes"] stringValue]];
    [self.seconds setText:[run[@"seconds"] stringValue]];
    [self.practiceRunDate setDate:run[@"practiceRunDate"]];
}

- (IBAction)cancelButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)saveButtonTapped:(id)sender {
    [self.practiceRunSaveIndicator setHidden:NO];
    
    CKDatabase *privateDatabase = [[CKContainer defaultContainer] privateCloudDatabase];
    
    [self updateRunFromUI];
    
    __weak ICFPracticeDetailViewController *weakSelf = self;
    [privateDatabase saveRecord:self.runData
             completionHandler:^(CKRecord *record, NSError *error) {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [weakSelf.practiceRunSaveIndicator setHidden:YES];
                     if (weakSelf.indexPathForRun) {
                         [weakSelf.runDataDelegate runUpdated:self.runData
                                                 forIndexPath:self.indexPathForRun];
                     } else {
                         [weakSelf.runDataDelegate runAdded:self.runData];
                     }
                     
                     [weakSelf.navigationController popViewControllerAnimated:YES];
                 });
             }];
}

@end

//
//  ICFRaceDetailViewController.m
//  CloudTracker
//
//  Created by Joe Keeley on 10/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFRaceDetailViewController.h"
#import "AppDelegate.h"

@interface ICFRaceDetailViewController ()

@end

@implementation ICFRaceDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.raceSaveButton setEnabled:self.connectedToiCloud];
    
    [self populateUIFromRaceRecord:self.raceData];
}

- (NSString *)selectedDistanceUnits {
    NSString *distanceUnitString = @"";
    switch (self.distanceUnit.selectedSegmentIndex)
    {
        case 0:
            distanceUnitString = @"Miles";
            break;
        case 1:
            distanceUnitString = @"Kilometers";
            break;
        case 2:
            distanceUnitString = @"Meters";
            break;
            
        default:
            break;
    }
    return distanceUnitString;
}

- (NSInteger)segmentForDistanceUnitString:(NSString *)unitString {
    NSInteger index = 0;
    if ([unitString isEqualToString:@"Miles"])
    {
        index = 0;
    }
    if ([unitString isEqualToString:@"Kilometers"])
    {
        index = 1;
    }
    if ([unitString isEqualToString:@"Meters"])
    {
        index = 2;
    }
    return index;
}

- (void)updateRaceFromUI {

    if (!self.raceData)
    {
        self.raceData = [[CKRecord alloc] initWithRecordType:@"Race"];
    }
    if (![self.raceData objectForKey:@"racer"])
    {
        
        AppDelegate *appDelegate =
        (AppDelegate *)[[UIApplication sharedApplication] delegate];
        
        CKRecord *userRecord = appDelegate.myUserRecord;

        if (userRecord)
        {
            CKReference *racerReference =
            [[CKReference alloc] initWithRecord:userRecord
                                         action:CKReferenceActionNone];
            
            self.raceData[@"racer"] = racerReference;
            self.raceData[@"racerName"] = userRecord[@"name"];
        }
    }
    self.raceData[@"raceName"] = self.raceName.text;
    self.raceData[@"location"] = self.location.text;
    self.raceData[@"distance"] = [NSNumber numberWithFloat:[self.distance.text floatValue]];
    self.raceData[@"distanceUnits"] = [self selectedDistanceUnits];
    self.raceData[@"hours"] = [NSNumber numberWithInteger:[self.hours.text integerValue]];
    self.raceData[@"minutes"] = [NSNumber numberWithInteger:[self.minutes.text integerValue]];
    self.raceData[@"seconds"] = [NSNumber numberWithInteger:[self.seconds.text integerValue]];
    self.raceData[@"raceDate"] = [self.datePicker date];
}

- (void)populateUIFromRaceRecord:(CKRecord *)race {
    if (!race)
    {
        return;
    }
    [self.raceName setText:race[@"raceName"]];
    [self.location setText:race[@"location"]];
    [self.distance setText:[race[@"distance"] stringValue]];
        
    [self.distanceUnit setSelectedSegmentIndex:
     [self segmentForDistanceUnitString:race[@"distanceUnits"]]];
        
    [self.hours setText:[race[@"hours"] stringValue]];
    [self.minutes setText:[race[@"minutes"] stringValue]];
    [self.seconds setText:[race[@"seconds"] stringValue]];
    [self.datePicker setDate:race[@"raceDate"]];
}

- (IBAction)cancelButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)saveButtonTapped:(id)sender {
    [self.saveRaceActivityIndicator setHidden:NO];
    CKDatabase *publicDatabase = [[CKContainer defaultContainer] publicCloudDatabase];
    
    [self updateRaceFromUI];

    __weak ICFRaceDetailViewController *weakSelf = self;
    [publicDatabase saveRecord:self.raceData
             completionHandler:^(CKRecord *record, NSError *error) {
                 dispatch_async(dispatch_get_main_queue(), ^{
                     [weakSelf.saveRaceActivityIndicator setHidden:YES];
                     if (weakSelf.indexPathForRace) {
                         [weakSelf.raceDataDelegate raceUpdated:record
                                                   forIndexPath:weakSelf.indexPathForRace];
                     } else {
                         [weakSelf.raceDataDelegate raceAdded:record];
                     }
                     
                     [weakSelf.navigationController popViewControllerAnimated:YES];
                 });
             }];
    
}

@end

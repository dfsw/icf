//
//  ICFNoteTypeSelectionTableViewController.m
//  HandoffNotes
//
//  Created by Joe Keeley on 11/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFNoteTypeSelectionTableViewController.h"
#import "ICFManualNoteTableViewController.h"

@interface ICFNoteTypeSelectionTableViewController ()
@property (nonatomic, strong) NSUserActivity *resumingUserActivity;
@end

@implementation ICFNoteTypeSelectionTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end

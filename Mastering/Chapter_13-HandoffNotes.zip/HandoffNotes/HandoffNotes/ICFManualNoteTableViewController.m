//
//  ICFManualNoteTableViewController.m
//  HandoffNotes
//
//  Created by Joe Keeley on 11/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFManualNoteTableViewController.h"
#import "ICFManualNoteViewController.h"

@interface ICFManualNoteTableViewController ()
@property (nonatomic, strong) NSMutableArray *noteList;
- (IBAction)addButtonTapped:(id)sender;
@end

@implementation ICFManualNoteTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSUbiquitousKeyValueStore *iCloudKeyValueStore =
    [NSUbiquitousKeyValueStore defaultStore];
    
    NSArray *noteList =
    [iCloudKeyValueStore arrayForKey:@"notelist"];
    
    self.noteList = [NSMutableArray arrayWithArray:noteList];
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)saveNoteList {
    NSArray *noteArray = [NSArray arrayWithArray:self.noteList];
    
    NSUbiquitousKeyValueStore *iCloudKeyValueStore =
    [NSUbiquitousKeyValueStore defaultStore];
    
    [iCloudKeyValueStore setArray:noteArray forKey:@"notelist"];
    
    [iCloudKeyValueStore synchronize];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.noteList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"manualNoteListCell" forIndexPath:indexPath];
    
    NSDictionary *manualNote = self.noteList[indexPath.row];
    [cell.textLabel setText:manualNote[@"title"]];
    NSDate *noteDate = manualNote[@"date"];
    [cell.detailTextLabel setText:noteDate.description];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.noteList removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [self saveNoteList];
    }
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showNoteDetail"]) {
        
        ICFManualNoteViewController *noteVC =
        (ICFManualNoteViewController *)segue.destinationViewController;
        
        NSUInteger selectedIndex = [[self.tableView indexPathForSelectedRow] row];
        NSDictionary *note = [self.noteList objectAtIndex:selectedIndex];
        
        if ([sender isKindOfClass:[NSUserActivity class]]) {
            //Update the note with continuation state
            NSUserActivity *activity = (NSUserActivity *)sender;
            note = @{@"title":activity.userInfo[@"noteTitle"],
                     @"note":activity.userInfo[@"noteText"],
                     @"date":note[@"date"]};
        }
        [noteVC setNote:note];
        [noteVC setNoteIndex:selectedIndex];
    }
}

- (IBAction)unwindSegueForNoteSave:(UIStoryboardSegue *)segue {
    ICFManualNoteViewController *noteVC = (ICFManualNoteViewController *)segue.sourceViewController;
    [self.noteList replaceObjectAtIndex:noteVC.noteIndex
                             withObject:noteVC.note];
    [self saveNoteList];
    
    NSIndexPath *updatedIndexPath = [NSIndexPath indexPathForRow:noteVC.noteIndex
                                                   inSection:0];

    [self.tableView reloadRowsAtIndexPaths:@[updatedIndexPath]
                          withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Button actions
- (IBAction)addButtonTapped:(id)sender {
    NSDictionary *newNote = @{@"title":@"New Note",
                              @"note":@"",
                              @"date":[NSDate date]};
    [self.noteList addObject:newNote];
    [self saveNoteList];
    
    NSUInteger indexForNewNote = [self.noteList indexOfObject:newNote];
    NSIndexPath *newIndexPath = [NSIndexPath indexPathForRow:indexForNewNote
                                                   inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[newIndexPath]
                          withRowAnimation:UITableViewRowAnimationAutomatic];
}

#pragma mark - Restoring User Activity
- (void)restoreUserActivityState:(NSUserActivity *)activity {
    if ([activity.userInfo objectForKey:@"noteIndex"]) {
        NSNumber *resumeNoteIndex = [[activity userInfo] objectForKey:@"noteIndex"];
        
        NSIndexPath *resumeIndexPath = [NSIndexPath indexPathForRow:[resumeNoteIndex integerValue]
                                                          inSection:0];
        [self.tableView selectRowAtIndexPath:resumeIndexPath
                                    animated:NO
                              scrollPosition:UITableViewScrollPositionNone];
        
        [self performSegueWithIdentifier:@"showNoteDetail" sender:activity];        
    }
}


@end

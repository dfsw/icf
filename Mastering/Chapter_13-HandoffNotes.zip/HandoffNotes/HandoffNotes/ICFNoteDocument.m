//
//  ICFNoteDocument.m
//  HandoffNotes
//
//  Created by Joe Keeley on 12/2/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFNoteDocument.h"

@implementation ICFNoteDocument

- (void)setNoteTitle:(NSString *)newNoteTitle
{
    NSString *oldNoteTitle = _noteTitle;
    _noteTitle = [newNoteTitle copy];
    
    SEL setNoteTitle = @selector(setNoteTitle:);
    
    [self.undoManager setActionName:@"Title Change"];
    [self.undoManager registerUndoWithTarget:self
                                    selector:setNoteTitle
                                      object:oldNoteTitle];
}

- (void)setNoteText:(NSString *)newNoteText
{
    NSString *oldNoteText = _noteText;
    _noteText = [newNoteText copy];
    
    SEL setNoteText = @selector(setNoteText:);
    
    [self.undoManager setActionName:@"Text Change"];
    [self.undoManager registerUndoWithTarget:self
                                    selector:setNoteText
                                      object:oldNoteText];
}

- (id)contentsForType:(NSString *)typeName
                error:(NSError *__autoreleasing *)outError
{
    NSMutableData *data = [NSMutableData data];
    NSKeyedArchiver *archiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:data];
    [archiver encodeObject:self.noteTitle forKey:@"noteTitleKey"];
    [archiver encodeObject:self.noteText forKey:@"noteTextKey"];
    [archiver finishEncoding];

    return data;
}

- (BOOL)loadFromContents:(id)contents
                  ofType:(NSString *)typeName
                   error:(NSError *__autoreleasing *)outError
{
    NSData *data = (NSData *)contents;
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc] initForReadingWithData:data];
    
    self.noteText = [unarchiver decodeObjectOfClass:[NSString class] forKey:@"noteTextKey"];
    self.noteTitle = [unarchiver decodeObjectOfClass:[NSString class] forKey:@"noteTitleKey"];

    return YES;
}


@end

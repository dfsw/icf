//
//  ICFManualNoteViewController.m
//  HandoffNotes
//
//  Created by Joe Keeley on 11/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFManualNoteViewController.h"

@interface ICFManualNoteViewController () <UITextFieldDelegate, UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UITextField *noteTitle;
@property (weak, nonatomic) IBOutlet UITextView *noteDetail;
- (IBAction)cancelButtonTapped:(id)sender;
@end

@implementation ICFManualNoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.noteTitle setText:self.note[@"title"]];
    [self.noteDetail setText:self.note[@"note"]];
}

- (void)viewWillAppear:(BOOL)animated {
    
    NSUserActivity *noteActivity = [[NSUserActivity alloc]
    initWithActivityType:@"com.explore-systems.handoffnotes.manual.editing"];

    noteActivity.userInfo = @{@"noteIndex":@(self.noteIndex),
                              @"noteTitle":self.note[@"title"],
                              @"noteText":self.note[@"note"]};

    [noteActivity setDelegate:self];
    self.userActivity = noteActivity;
}

#pragma mark - Actions
- (IBAction)cancelButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - User Activity management
- (void)updateUserActivityState:(NSUserActivity *)activity {
    activity.userInfo = @{@"noteIndex":@(self.noteIndex),
                          @"noteTitle":self.noteTitle.text,
                          @"noteText":self.noteDetail.text};
    NSLog(@"user info is: %@",activity.userInfo);
}

- (void)userActivityWasContinued:(NSUserActivity *)userActivity {
    [self.userActivity invalidate];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"saveUnwindSegue"]) {
        self.note = @{@"title":self.noteTitle.text,
                      @"note":self.noteDetail.text,
                      @"date":[NSDate date]};
    }
}

#pragma mark - UITextFieldDelegate
- (BOOL)textField:(UITextField *)textField
shouldChangeCharactersInRange:(NSRange)range
replacementString:(NSString *)string {
    
    [self.userActivity setNeedsSave:YES];
    return YES;
}

#pragma mark - UITextViewDelegate
- (void)textViewDidChange:(UITextView *)textView {
    [self.userActivity setNeedsSave:YES];
}

@end

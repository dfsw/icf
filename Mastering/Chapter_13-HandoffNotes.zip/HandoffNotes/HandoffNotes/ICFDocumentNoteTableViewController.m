//
//  ICFDocumentNoteTableViewController.m
//  HandoffNotes
//
//  Created by Joe Keeley on 12/1/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFDocumentNoteTableViewController.h"
#import "ICFDocumentNoteViewController.h"

@interface ICFDocumentNoteTableViewController ()

@property (nonatomic, strong) NSMutableArray *noteDocumentList;
@property (nonatomic, strong) NSMetadataQuery *noteQuery;

- (NSMetadataQuery*)noteListQuery;
- (void)processFiles:(NSNotification*)notification;

@end

@implementation ICFDocumentNoteTableViewController

- (NSMetadataQuery*)noteListQuery
{
    NSMetadataQuery *setupQuery = [[NSMetadataQuery alloc] init];
    [setupQuery setSearchScopes:
     @[NSMetadataQueryUbiquitousDocumentsScope]];
    
    NSString *filePattern = [NSString stringWithFormat:
                             @"*.%@",@"icfnote"];
    
    [setupQuery setPredicate:[NSPredicate predicateWithFormat:
                              @"%K LIKE %@",NSMetadataItemFSNameKey,filePattern]];
    
    return setupQuery;
}

- (void)processFiles:(NSNotification*)notification
{
    NSMutableArray *foundFiles = [[NSMutableArray alloc] init];
    [self.noteQuery disableUpdates];
    
    NSArray *queryResults = [self.noteQuery results];
    for (NSMetadataItem *result in queryResults) {
        
        NSURL *fileURL =
        [result valueForAttribute:NSMetadataItemURLKey];

        [foundFiles addObject:fileURL];
    }
    
    [self.noteDocumentList removeAllObjects];
    [self.noteDocumentList addObjectsFromArray:foundFiles];
    [self.tableView reloadData];
    
    [self.noteQuery enableUpdates];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.noteDocumentList = [[NSMutableArray alloc] init];

    self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    self.noteQuery = [self noteListQuery];
    
    NSNotificationCenter *notifCenter =
    [NSNotificationCenter defaultCenter];
    
    NSString *metadataFinished =
    NSMetadataQueryDidFinishGatheringNotification;
    
    [notifCenter addObserver:self
                    selector:@selector(processFiles:)
                        name:metadataFinished
                      object:nil];
    
    NSString *metadataUpdated =
    NSMetadataQueryDidUpdateNotification;
    
    [notifCenter addObserver:self
                    selector:@selector(processFiles:)
                        name:metadataUpdated
                      object:nil];

    [self.noteQuery startQuery];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.noteDocumentList count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"documentNoteListCell" forIndexPath:indexPath];
    
    NSURL *myNoteURL =
    [self.noteDocumentList objectAtIndex:[indexPath row]];
    
    NSString *noteName =
    [[myNoteURL lastPathComponent] stringByDeletingPathExtension];
    
    [cell.textLabel setText:noteName];
    
    NSMetadataItem *item = [[self.noteQuery results] objectAtIndex:indexPath.row];
    NSDate *itemCreateDate = [item valueForKey:NSMetadataItemFSCreationDateKey];
    [cell.detailTextLabel setText:itemCreateDate.description];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSURL *myNoteURL = [self.noteDocumentList objectAtIndex:[indexPath row]];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSFileCoordinator *fileCoordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
            [fileCoordinator coordinateWritingItemAtURL:myNoteURL
                                                options:NSFileCoordinatorWritingForDeleting
                                                  error:nil
                                             byAccessor:^(NSURL *newURL){
                                                 NSFileManager *fileManager = [[NSFileManager alloc] init];
                                                 [fileManager removeItemAtURL:newURL error:nil];
                                             }];
        });
        
        [self.noteDocumentList removeObjectAtIndex:[indexPath row]];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }}


#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"addNewDocNote"]) {
        ICFDocumentNoteViewController *noteVC = (ICFDocumentNoteViewController *)[segue destinationViewController];
        [noteVC setNoteURL:nil];

    }
    if ([segue.identifier isEqualToString:@"showDocNoteDetail"]) {
        NSIndexPath *indexPath = [self.tableView indexPathForSelectedRow];
        NSURL *selectedNote = self.noteDocumentList[indexPath.row];
        ICFDocumentNoteViewController *noteVC = (ICFDocumentNoteViewController *)[segue destinationViewController];
        [noteVC setNoteURL:selectedNote];
    }
}

#pragma mark - Restoring User Activity

- (void)restoreUserActivityState:(NSUserActivity *)activity {
    if ([activity.userInfo objectForKey:@"fileURL"]) {
        NSURL *fileURL = [activity.userInfo objectForKey:@"fileURL"];

        NSInteger fileURLIndex = NSNotFound;
        for (NSURL *compURL in self.noteDocumentList)
        {
            if ([[fileURL absoluteString] isEqualToString:[compURL absoluteString]])
            {
                fileURLIndex = [self.noteDocumentList indexOfObject:compURL];
                break;
            }
        }

        if (fileURLIndex != NSNotFound)
        {
            NSIndexPath *resumeIndexPath = [NSIndexPath indexPathForRow:fileURLIndex
                                                              inSection:0];
            
            [self.tableView selectRowAtIndexPath:resumeIndexPath
                                        animated:NO
                                  scrollPosition:UITableViewScrollPositionNone];
            
            [self performSegueWithIdentifier:@"showDocNoteDetail" sender:activity];
        }
    }
}

@end

//
//  ICFNoteTypeSelectionTableViewController.h
//  HandoffNotes
//
//  Created by Joe Keeley on 11/16/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFNoteTypeSelectionTableViewController : UITableViewController

@end

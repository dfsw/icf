//
//  ICFDocumentNoteViewController.m
//  HandoffNotes
//
//  Created by Joe Keeley on 12/1/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFDocumentNoteViewController.h"
#import "ICFNoteDocument.h"

NSString * const kICFDocumentDirectoryName = @"Documents";
NSString * const kICFDocumentExtension = @".icfnote";

@interface ICFDocumentNoteViewController ()

@property (weak, nonatomic) IBOutlet UITextField *noteTitle;
@property (weak, nonatomic) IBOutlet UITextView *noteDetail;
@property (nonatomic, strong) ICFNoteDocument *noteDocument;

- (IBAction)cancelButtonTapped:(id)sender;
- (IBAction)saveButtonTapped:(id)sender;

@end

@implementation ICFDocumentNoteViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    if ([self noteURL]) {
        self.noteDocument =
        [[ICFNoteDocument alloc] initWithFileURL:[self noteURL]];
        
        [self.noteDocument openWithCompletionHandler:^(BOOL success) {
            
            [self.noteTitle setText:[self.noteDocument noteTitle]];
            [self.noteDetail setText:[self.noteDocument noteText]];
            
            UIDocumentState state = self.noteDocument.documentState;
            
            if (state == UIDocumentStateNormal) {
                [self.noteTitle becomeFirstResponder];
                
                NSUserActivity *noteActivity = [[NSUserActivity alloc]
                initWithActivityType:@"com.explore-systems.handoffnotes.document.editing"];
                                
                noteActivity.userInfo = @{@"fileURL":self.noteURL};

                [self.noteDocument setUserActivity:noteActivity];
                [noteActivity becomeCurrent];
            }
        }];

    }
}

- (IBAction)cancelButtonTapped:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)saveButtonTapped:(id)sender {
    if (![self noteURL]) {
        dispatch_queue_t background =
        dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        
        dispatch_async(background, ^{
            NSFileManager *fileManager = [NSFileManager defaultManager];
            NSURL *newNoteURL = [fileManager URLForUbiquityContainerIdentifier:nil];
            newNoteURL = [newNoteURL URLByAppendingPathComponent:kICFDocumentDirectoryName isDirectory:YES];
            NSString *filename = [NSString stringWithFormat:@"%@%@", [self.noteTitle text],kICFDocumentExtension];
            newNoteURL = [newNoteURL URLByAppendingPathComponent:filename];
            
            self.noteDocument =
            [[ICFNoteDocument alloc] initWithFileURL:newNoteURL];

            [self.noteDocument setNoteTitle:[self.noteTitle text]];
            [self.noteDocument setNoteText:[self.noteDetail text]];
            [self.noteDocument saveToURL:newNoteURL
                        forSaveOperation:UIDocumentSaveForCreating
                       completionHandler:^(BOOL created){
                           dispatch_async(dispatch_get_main_queue(), ^{
                               
                               [self.noteDocument closeWithCompletionHandler:nil];
                               
                               [self.navigationController popViewControllerAnimated:YES];
                           });
                       }];
        });

    }
    else
    {
        [self.noteDocument setNoteTitle:[self.noteTitle text]];
        [self.noteDocument setNoteText:[self.noteDetail text]];
        
        [self.noteDocument closeWithCompletionHandler:nil];
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    
}

@end

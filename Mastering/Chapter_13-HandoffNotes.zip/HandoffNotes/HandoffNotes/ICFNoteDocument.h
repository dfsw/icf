//
//  ICFNoteDocument.h
//  HandoffNotes
//
//  Created by Joe Keeley on 12/2/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFNoteDocument : UIDocument

@property (nonatomic, copy) NSString *noteTitle;
@property (nonatomic, copy) NSString *noteText;

@end

//
//  AppDelegate.m
//  HandoffNotes
//
//  Created by Joe Keeley on 11/15/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "AppDelegate.h"
#import "ICFManualNoteTableViewController.h"
#import "ICFDocumentNoteTableViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)setupiCloud
{
    dispatch_queue_t background_queue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,
                              0);
    
    dispatch_async(background_queue, ^{
        
        NSFileManager *fileManager =
        [NSFileManager defaultManager];
        
        NSURL *iCloudURL =
        [fileManager URLForUbiquityContainerIdentifier:nil];
        
        if (iCloudURL != nil) {
            NSLog(@"iCloud URL is available");
        }
        else
        {
            NSLog(@"iCloud URL is NOT available");
        }
    });
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self setupiCloud];
    return YES;
}

- (BOOL)application:(UIApplication *)application willContinueUserActivityWithType:(NSString *)userActivityType {
    return YES;
}

- (BOOL)application:(UIApplication *)application continueUserActivity:(NSUserActivity *)userActivity restorationHandler:(void (^)(NSArray *))restorationHandler {
    if ([userActivity.activityType isEqualToString:@"com.explore-systems.handoffnotes.manual.editing"]) {
        
        //First synchronize key value store so values are in place
        NSUbiquitousKeyValueStore *iCloudKeyValueStore =
        [NSUbiquitousKeyValueStore defaultStore];

        [iCloudKeyValueStore synchronize];

        //navigate to correct note
        UINavigationController *navController = (UINavigationController *)self.window.rootViewController;
        [navController popToRootViewControllerAnimated:NO];
        
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main"
                                                             bundle:[NSBundle mainBundle]];

        ICFManualNoteTableViewController *manualListVC =
         [storyboard instantiateViewControllerWithIdentifier:@"ICFManualNoteTableViewController"];
                
        [navController pushViewController:manualListVC animated:NO];

        restorationHandler(@[manualListVC]);
        
        return YES;
    }
    if ([userActivity.activityType isEqualToString:@"com.explore-systems.handoffnotes.document.editing"]) {
        //navigate to correct note
        UINavigationController *navController = (UINavigationController *)self.window.rootViewController;
        [navController popToRootViewControllerAnimated:NO];

        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        ICFDocumentNoteTableViewController *documentListVC = [storyboard instantiateViewControllerWithIdentifier:@"ICFDocumentNoteTableViewController"];
        [navController pushViewController:documentListVC animated:NO];

        restorationHandler(@[documentListVC]);
    }
    return NO;
}


@end

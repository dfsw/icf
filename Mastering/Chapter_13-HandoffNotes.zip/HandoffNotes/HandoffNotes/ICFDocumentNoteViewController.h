//
//  ICFDocumentNoteViewController.h
//  HandoffNotes
//
//  Created by Joe Keeley on 12/1/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFDocumentNoteViewController : UIViewController

@property (strong, nonatomic) NSURL *noteURL;
@property (nonatomic) NSUInteger noteIndex;

@end

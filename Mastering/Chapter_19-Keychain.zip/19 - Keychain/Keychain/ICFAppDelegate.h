//
//  ICFAppDelegate.h
//  Keychain
//
//  Created by Kyle Richter on 4/28/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ICFViewController;

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ICFViewController *viewController;
@property (strong, nonatomic) UINavigationController *navController;

@end

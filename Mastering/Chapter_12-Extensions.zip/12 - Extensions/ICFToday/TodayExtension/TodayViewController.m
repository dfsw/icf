//
//  TodayViewController.m
//  TodayExtension
//
//  Created by Kyle Richter on 12/31/14.
//  Copyright (c) 2014 Kyle Richter. All rights reserved.
//

#import "TodayViewController.h"
#import <NotificationCenter/NotificationCenter.h>

@interface TodayViewController () <NCWidgetProviding>

@end

@implementation TodayViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}


- (void)widgetPerformUpdateWithCompletionHandler:(void (^)(NCUpdateResult))completionHandler
{
    self.preferredContentSize = CGSizeMake(0, 20);
    [self refreshAction: nil];
    
    completionHandler(NCUpdateResultNewData);
}

- (IBAction)refreshAction:(id)sender
{
    _priceLabel.text = [NSString stringWithFormat:@"AAPL: $%@", [self getStockPrice]];
}

-(NSString *)getStockPrice
{
    NSURL *url = [NSURL URLWithString:@"http://finance.yahoo.com/d/quotes.csv?s=AAPL&f=a"];
    NSError *error = nil;
    NSString *quote = [NSString stringWithContentsOfURL:url encoding:NSASCIIStringEncoding error:&error];
    
    return quote;
}


@end

//
//  AppDelegate.h
//  ICFToday
//
//  Created by Kyle Richter on 12/31/14.
//  Copyright (c) 2014 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end


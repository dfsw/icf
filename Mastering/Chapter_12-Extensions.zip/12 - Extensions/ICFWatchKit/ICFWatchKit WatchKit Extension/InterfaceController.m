//
//  InterfaceController.m
//  ICFWatchKit WatchKit Extension
//
//  Created by Kyle Richter on 1/2/15.
//  Copyright (c) 2015 Kyle Richter. All rights reserved.
//

#import "InterfaceController.h"


@interface InterfaceController()

@end


@implementation InterfaceController

- (void)awakeWithContext:(id)context
{
    [super awakeWithContext:context];
}


- (IBAction)refresh
{
    _helloWorldLabel.text = @"Im alive!";
    
}
@end




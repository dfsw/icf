//
//  ViewController.h
//  ICFWatchKit
//
//  Created by Kyle Richter on 1/2/15.
//  Copyright (c) 2015 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end


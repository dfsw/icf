//
//  AppDelegate.m
//  ShoutOut
//
//  Created by Joe Keeley on 9/28/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    [[UIApplication sharedApplication] registerForRemoteNotifications];
    
    UIUserNotificationSettings *notifSettings =
    [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert |
     UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
    
    [[UIApplication sharedApplication] registerUserNotificationSettings:notifSettings];
    
    return YES;
}

- (void)application:(UIApplication *)application
didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken {
    
    NSString *formattedTokenString = [deviceToken description];
    
    NSString *removedSpacesTokenString =
    [formattedTokenString stringByReplacingOccurrencesOfString:@" "
                                                    withString:@""];
    
    NSString *trimmedTokenString =
    [removedSpacesTokenString stringByTrimmingCharactersInSet:
     [NSCharacterSet characterSetWithCharactersInString:@"<>"]];
    
    [self setPushTokenString:trimmedTokenString];
}

- (void)application:(UIApplication *)application
didFailToRegisterForRemoteNotificationsWithError:(NSError *)error {
    NSLog(@"Error in push registration: %@", error.localizedDescription);
}

- (void)application:(UIApplication *)application
didReceiveRemoteNotification:(NSDictionary *)userInfo {
    NSString *message =
    [[[userInfo objectForKey:@"aps"] objectForKey:@"alert"] objectForKey:@"body"];
    
    NSString *appState = ([application applicationState] == UIApplicationStateActive) ?
    @"app Active" : @"app in Background";
    
    [self presentAlertWithMessage:
     [NSString stringWithFormat:@"Received remote push for app state %@: %@",
      appState, message]];
}

- (void)application:(UIApplication *)application
didReceiveLocalNotification:(UILocalNotification *)notification {
    NSString *message = [notification alertBody];

    NSString *appState = ([application applicationState] == UIApplicationStateActive) ?
    @"app Active" : @"app in Background";

    [self presentAlertWithMessage:
     [NSString stringWithFormat:@"Received local notification for app state %@: %@",
      appState, message]];
}

- (void)presentAlertWithMessage:(NSString *)message {
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"Notification Received"
                                        message:message
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *dismissAction =
    [UIAlertAction actionWithTitle:@"OK"
                             style:UIAlertActionStyleCancel
                           handler:^(UIAlertAction *action){
                               [self.window.rootViewController dismissViewControllerAnimated:YES completion:nil];
                           }];
    
    [alert addAction:dismissAction];
    
    [self.window.rootViewController presentViewController:alert animated:YES completion:nil];
}

@end

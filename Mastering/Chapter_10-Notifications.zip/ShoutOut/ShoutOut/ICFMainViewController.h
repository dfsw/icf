//
//  ICFMainViewController.h
//  ShoutOut
//
//  Created by Joe Keeley on 9/28/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFMainViewController : UIViewController <UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *shoutTextField;
@property (weak, nonatomic) IBOutlet UIView *activityView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
- (IBAction)setReminder:(id)sender;
- (IBAction)shoutTapped:(id)sender;
@end

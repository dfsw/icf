//
//  ICFMainViewController.m
//  ShoutOut
//
//  Created by Joe Keeley on 9/28/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFMainViewController.h"
#import "AppDelegate.h"

@interface ICFMainViewController ()

@end

@implementation ICFMainViewController

- (IBAction)setReminder:(id)sender {
    NSDate *now = [NSDate date];
    UILocalNotification *reminderNotification = [[UILocalNotification alloc] init];
    
    //when notification should fire
    [reminderNotification setFireDate:[now dateByAddingTimeInterval:15]];
    [reminderNotification setTimeZone:[NSTimeZone defaultTimeZone]];
    
    //what notification should look like
    [reminderNotification setAlertBody:@"Don't forget to Shout Out!"];
    [reminderNotification setAlertAction:@"Shout Now"];
    [reminderNotification setSoundName:UILocalNotificationDefaultSoundName];
    [reminderNotification setApplicationIconBadgeNumber:1];
    
    //schedule notification
    [[UIApplication sharedApplication]
     scheduleLocalNotification:reminderNotification];
    
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"Reminder"
                                        message:@"Your Reminder has been Scheduled"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *dismissAction =
    [UIAlertAction actionWithTitle:@"OK Thanks!"
                             style:UIAlertActionStyleCancel
                           handler:^(UIAlertAction *action){
                               [self dismissViewControllerAnimated:YES completion:nil];
                           }];
    
    [alert addAction:dismissAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (IBAction)shoutTapped:(id)sender {
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    NSLog(@"Shout tapped.  Paste this to Terminal to send push:  ");
    NSLog(@"php shout.php \"%@\" \"%@\" ", self.shoutTextField.text, appDelegate.pushTokenString);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

@end

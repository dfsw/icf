//
//  AppDelegate.h
//  ShoutOut
//
//  Created by Joe Keeley on 9/28/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, strong) NSString *pushTokenString;

@end


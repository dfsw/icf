<?php
    
    if (!isset($argv[1]) || !isset($argv[2])) {
        exit("Message and device required" . PHP_EOL);
    }
    
    $deviceID = $argv[2];
    
    $push_message = $argv[1];

    //customize the payload here to try different approaches, sounds, badge settings, etc 
    $payload = '{"aps":{"alert":"' . $push_message . '","sound":"shout_out.caf"}}';
    //$payload = '{"aps":{"alert": {"body":"' . $push_message . '", "action-loc-key": "See Push"},"sound":"shout_out.caf"}}';

    echo $payload;
    
    $ctx = stream_context_create();
    stream_context_set_option($ctx, 'ssl', 'local_cert', 'shoutout.pem');
    //stream_context_set_option($ctx, 'ssl', 'passphrase', $passphrase); <<--uncomment this if you have a passphrase on your certificate
    
    $fp = stream_socket_client('ssl://gateway.sandbox.push.apple.com:2195', $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
    
    if (!$fp) {
        exit("Failed to connect to APNs: $err $errstr");
    } else {
        echo 'Connected to APNs. ' . PHP_EOL;
    }
    
    $push = chr(0) . pack('n', 32) . pack('H*', $deviceID) . pack('n', strlen($payload)) . $payload;
    
    // Send it to the server
    $result = fwrite($fp, $push, strlen($push));
    
    if ($result) {
        echo 'Push message delivered to APNs'.PHP_EOL;
    } else {
        echo 'Push message delivery failed' . $item . '<br />';
    }
    
    if ($fp) {
        fclose($fp);
        echo 'APNS connection closed.'.PHP_EOL;
    } 
?>

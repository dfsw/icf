//
//  AppDelegate.h
//  ICFFever
//
//  Created by Kyle Richter on 11/18/14.
//  Copyright (c) 2014 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HealthKit;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (nonatomic) HKHealthStore *healthStore;

@end


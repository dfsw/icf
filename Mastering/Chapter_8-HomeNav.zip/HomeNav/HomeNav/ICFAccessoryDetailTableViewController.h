//
//  ICFAccessoryDetailTableViewController.h
//  HomeNav
//
//  Created by Joe Keeley on 12/30/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HomeKit;

@interface ICFAccessoryDetailTableViewController : UITableViewController

@property (nonatomic, strong) HMAccessory *detailAccessory;
@property (nonatomic, strong) HMHome *home;

@end

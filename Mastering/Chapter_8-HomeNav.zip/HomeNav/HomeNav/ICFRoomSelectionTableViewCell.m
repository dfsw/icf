//
//  ICFRoomSelectionTableViewCell.m
//  HomeNav
//
//  Created by Joe Keeley on 1/2/15.
//  Copyright (c) 2015 Joe Keeley. All rights reserved.
//

#import "ICFRoomSelectionTableViewCell.h"

@implementation ICFRoomSelectionTableViewCell

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    if (selected) {
        [self setAccessoryType:UITableViewCellAccessoryCheckmark];
    } else {
        [self setAccessoryType:UITableViewCellAccessoryNone];
    }
}

@end

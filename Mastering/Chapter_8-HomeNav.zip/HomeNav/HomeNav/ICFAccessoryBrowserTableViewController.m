//
//  ICFAccessoryBrowserTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 12/26/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAccessoryBrowserTableViewController.h"

@interface ICFAccessoryBrowserTableViewController () <HMAccessoryBrowserDelegate>

@property (nonatomic, strong) NSMutableArray *accessoriesList;
@property (nonatomic, strong) HMAccessoryBrowser *accessoryBrowser;

- (void)stopSearchingButtonTapped:(id)sender;

@end

@implementation ICFAccessoryBrowserTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewDidAppear:(BOOL)animated {
    [self searchButtonTapped:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
    [self stopSearchingButtonTapped:nil];
}

#pragma mark - actions

- (IBAction)searchButtonTapped:(id)sender {
    self.accessoriesList = [[NSMutableArray alloc] init];
    [self.tableView reloadData];

    self.accessoryBrowser = [[HMAccessoryBrowser alloc] init];
    [self.accessoryBrowser setDelegate:self];
    [self.accessoryBrowser startSearchingForNewAccessories];
    
    UIBarButtonItem *stopButton = [[UIBarButtonItem alloc] initWithTitle:@"Stop" style:UIBarButtonItemStylePlain target:self action:@selector(stopSearchingButtonTapped:)];
    [self.navigationItem setRightBarButtonItem:stopButton];
}

- (void)stopSearchingButtonTapped:(id)sender {
    [self.accessoryBrowser stopSearchingForNewAccessories];
    self.accessoryBrowser = nil;

    UIBarButtonItem *searchButton = [[UIBarButtonItem alloc] initWithTitle:@"Search Now" style:UIBarButtonItemStylePlain target:self action:@selector(searchButtonTapped:)];
    [self.navigationItem setRightBarButtonItem:searchButton];
}

#pragma mark - Table view data source and delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.accessoriesList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"accessorySearchCell" forIndexPath:indexPath];
    
    HMAccessory *accessory = [self.accessoriesList objectAtIndex:indexPath.row];
    [cell.textLabel setText:accessory.name];
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] init];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    HMAccessory *selectedAccessory = [self.accessoriesList objectAtIndex:indexPath.row];
    
    UIAlertController *addAccAlertController = [UIAlertController alertControllerWithTitle:@"Add Accessory" message:@"Add accessory? Specify a name for your accessory - Siri will be able to use what you provide to refer to it directly." preferredStyle:UIAlertControllerStyleAlert];
    [addAccAlertController addAction:[UIAlertAction actionWithTitle:@"Add Accessory" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField *accNameTextField = addAccAlertController.textFields.firstObject;
        NSString *newAccName = accNameTextField.text;
        [self.home addAccessory:selectedAccessory completionHandler:^(NSError *error) {
            if (!error) {
                [selectedAccessory updateName:newAccName completionHandler:^(NSError *error) {
                    if (error) {
                        NSLog(@"Error updating name for selected accessory");
                    }
                }];
            } else {
                NSLog(@"Error adding selected accessory");
            }
        }];
    }]];
    [addAccAlertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [addAccAlertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        [textField setPlaceholder:@"New Accessory Name..."];
    }];
    [self presentViewController:addAccAlertController animated:YES completion:nil];

}

#pragma mark - HMAccessoryBrowserDelegate methods

- (void)accessoryBrowser:(HMAccessoryBrowser *)browser
     didFindNewAccessory:(HMAccessory *)accessory {
    
    [self.accessoriesList addObject:accessory];
    NSInteger rowAdded = [self.accessoriesList indexOfObject:accessory];
    NSIndexPath *addedIndexPath = [NSIndexPath indexPathForRow:rowAdded inSection:0];
    
    [self.tableView insertRowsAtIndexPaths:@[addedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)accessoryBrowser:(HMAccessoryBrowser *)browser didRemoveNewAccessory:(HMAccessory *)accessory {
    NSInteger rowRemoved = [self.accessoriesList indexOfObject:accessory];
    [self.accessoriesList removeObject:accessory];
    NSIndexPath *removedIndexPath = [NSIndexPath indexPathForRow:rowRemoved inSection:0];
    [self.tableView deleteRowsAtIndexPaths:@[removedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}


@end

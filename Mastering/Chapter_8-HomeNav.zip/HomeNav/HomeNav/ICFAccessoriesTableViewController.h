//
//  ICFAccessoriesTableViewController.h
//  HomeNav
//
//  Created by Joe Keeley on 12/26/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HomeKit;

@interface ICFAccessoriesTableViewController : UITableViewController

@property (nonatomic, strong) HMHome *home;

@end

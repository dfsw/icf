//
//  ICFRoomSelectionTableViewCell.h
//  HomeNav
//
//  Created by Joe Keeley on 1/2/15.
//  Copyright (c) 2015 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFRoomSelectionTableViewCell : UITableViewCell

@end

//
//  ICFAccessoryRoomSelectionTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 1/1/15.
//  Copyright (c) 2015 Joe Keeley. All rights reserved.
//

#import "ICFAccessoryRoomSelectionTableViewController.h"

@interface ICFAccessoryRoomSelectionTableViewController ()

@end

@implementation ICFAccessoryRoomSelectionTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)viewWillAppear:(BOOL)animated {
    NSInteger rowForRoom = [self.home.rooms indexOfObject:self.accessory.room];
    
    if (rowForRoom == NSNotFound) {
        rowForRoom = [self.home.rooms count];
    }
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:rowForRoom inSection:0];
    [self.tableView selectRowAtIndexPath:indexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.home.rooms count] + 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"roomSelectionCell" forIndexPath:indexPath];
    
    if (indexPath.row < [self.home.rooms count])
    {
        HMRoom *room = [self.home.rooms objectAtIndex:indexPath.row];
        [cell.textLabel setText:room.name];
    } else
    {
        NSString *roomForHomeText = [NSString stringWithFormat:@"Room for %@", self.home.name];
        [cell.textLabel setText:roomForHomeText];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    HMRoom *selectedRoom = nil;
    if (indexPath.row < [self.home.rooms count])
    {
        selectedRoom = [self.home.rooms objectAtIndex:indexPath.row];
    } else
    {
        selectedRoom = [self.home roomForEntireHome];
    }

    [self.home assignAccessory:self.accessory
                        toRoom:selectedRoom
             completionHandler:^(NSError *error) {
        if (error)
        {
            NSLog(@"Error assigning accessory to room: %@", error.localizedDescription);
        }
    }];
}

@end

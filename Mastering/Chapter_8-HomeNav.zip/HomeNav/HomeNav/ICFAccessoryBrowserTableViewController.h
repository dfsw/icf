//
//  ICFAccessoryBrowserTableViewController.h
//  HomeNav
//
//  Created by Joe Keeley on 12/26/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HomeKit;

@interface ICFAccessoryBrowserTableViewController : UITableViewController

@property (nonatomic, strong) HMHome *home;

- (IBAction)searchButtonTapped:(id)sender;

@end

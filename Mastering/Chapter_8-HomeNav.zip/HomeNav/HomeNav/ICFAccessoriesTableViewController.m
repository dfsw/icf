//
//  ICFAccessoriesTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 12/26/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAccessoriesTableViewController.h"
#import "ICFAccessoryBrowserTableViewController.h"
#import "ICFAccessoryDetailTableViewController.h"

@interface ICFAccessoriesTableViewController ()

@end

@implementation ICFAccessoriesTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSInteger searchAccessoriesRowCount = [tableView isEditing] ? 1 : 0;
    return [self.home.accessories count] + searchAccessoriesRowCount;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"accessoryNameCell" forIndexPath:indexPath];
    
    if (indexPath.row == 0 && [tableView isEditing]) {
        [cell.textLabel setText:@"Search for new accessories"];
        [cell.detailTextLabel setText:@""];
    } else {
        NSInteger row = [tableView isEditing] ? indexPath.row - 1 : indexPath.row;
        HMAccessory *accessory = [self.home.accessories objectAtIndex:row];
        [cell.textLabel setText:accessory.name];
        [cell.detailTextLabel setText:accessory.room.name];
    }
    return cell;
}

- (void)setEditing:(BOOL)editing animated:(BOOL)animated {
    [super setEditing:editing animated:animated];
    [self.tableView reloadData];
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return UITableViewCellEditingStyleInsert;
    } else {
        return UITableViewCellEditingStyleDelete;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        HMAccessory *accessory = [self.home.accessories objectAtIndex:(indexPath.row - 1)];
        [self.home removeAccessory:accessory completionHandler:^(NSError *error) {
            [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        }];
    }
    if (editingStyle == UITableViewCellEditingStyleInsert) {
        [self performSegueWithIdentifier:@"browseAccessoriesSegue" sender:nil];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] init];
}


#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"browseAccessoriesSegue"]) {
        ICFAccessoryBrowserTableViewController *accBrowserVC = (ICFAccessoryBrowserTableViewController *)segue.destinationViewController;
        [accBrowserVC setHome:self.home];
    }
    if ([segue.identifier isEqualToString:@"accessoryDetailSegue"]) {
        if ([sender isKindOfClass:[UITableViewCell class]]) {
            UITableViewCell *tappedCell = (UITableViewCell *)sender;
            NSIndexPath *tappedIndexPath = [self.tableView indexPathForCell:tappedCell];
            HMAccessory *accessory = [self.home.accessories objectAtIndex:tappedIndexPath.row];
            ICFAccessoryDetailTableViewController *accDetailVC = (ICFAccessoryDetailTableViewController *)segue.destinationViewController;
            
            [accDetailVC setDetailAccessory:accessory];
            [accDetailVC setHome:self.home];
        }
    }
    
}

@end

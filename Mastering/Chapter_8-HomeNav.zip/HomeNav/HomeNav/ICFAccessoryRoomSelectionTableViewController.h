//
//  ICFAccessoryRoomSelectionTableViewController.h
//  HomeNav
//
//  Created by Joe Keeley on 1/1/15.
//  Copyright (c) 2015 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HomeKit;

@interface ICFAccessoryRoomSelectionTableViewController : UITableViewController

@property (nonatomic, strong) HMAccessory *accessory;
@property (nonatomic, strong) HMHome *home;

@end

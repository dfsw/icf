//
//  ICFAccessoryDetailTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 12/30/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAccessoryDetailTableViewController.h"
#import "ICFAccessoryRoomSelectionTableViewController.h"

@interface ICFAccessoryDetailTableViewController ()

@end

@implementation ICFAccessoryDetailTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setTitle:self.detailAccessory.name];
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tableView reloadData];
}

#pragma mark - Table view data source and delegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 + [self.detailAccessory.services count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) {
        return @"Room";
    }
    HMService *service = [self.detailAccessory.services objectAtIndex:(section - 1)];
    return service.name;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return 1;
    }

    HMService *service = [self.detailAccessory.services objectAtIndex:(section - 1)];

    return [service.characteristics count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = nil;
    
    if (indexPath.section == 0) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"accessoryDetailRoomCell" forIndexPath:indexPath];
        [cell.textLabel setText:self.detailAccessory.room.name];
    }
    if (indexPath.section > 0) {
        cell = [tableView dequeueReusableCellWithIdentifier:@"accessoryDetailServiceCell" forIndexPath:indexPath];
        HMService *service = [self.detailAccessory.services objectAtIndex:(indexPath.section - 1)];
        HMCharacteristic *characteristic = [service.characteristics objectAtIndex:indexPath.row];

        [cell.textLabel setText:[self characteristicInfoForCharacteristic:characteristic]];
        [cell.detailTextLabel setText:[self propertyInfoForCharacteristic:characteristic]];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        return;
    }

    HMService *service = [self.detailAccessory.services objectAtIndex:(indexPath.section - 1)];
    HMCharacteristic *characteristic = [service.characteristics objectAtIndex:indexPath.row];
        
    if ([characteristic.characteristicType isEqualToString:HMCharacteristicTypeTargetLockMechanismState]) {
        [self handleLockTransitionForCharacteristic:characteristic];
    }
    
    if ([characteristic.characteristicType isEqualToString:HMCharacteristicTypePowerState]) {
        [self handlePowerTransitionForCharacteristic:characteristic];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - State Transition Handling
- (void)handleLockTransitionForCharacteristic:(HMCharacteristic *)characteristic {
    NSString *changeToState = @"";
    HMCharacteristicValueLockMechanismState targetState = HMCharacteristicValueLockMechanismStateUnknown;

    if ([characteristic.value integerValue] == HMCharacteristicValueLockMechanismStateUnknown ||
        [characteristic.value integerValue] == HMCharacteristicValueLockMechanismStateUnsecured) {
        changeToState = @"Locked";
        targetState = HMCharacteristicValueLockMechanismStateSecured;
    }
    if ([characteristic.value integerValue] == HMCharacteristicValueLockMechanismStateJammed ||
        [characteristic.value integerValue] == HMCharacteristicValueLockMechanismStateSecured) {
        changeToState = @"Unlocked";
        targetState = HMCharacteristicValueLockMechanismStateUnsecured;
    }
    NSString *changeToMessage = [NSString stringWithFormat:@"Change to %@?",changeToState];
    
    UIAlertController *changeAlertController = [UIAlertController alertControllerWithTitle:@"Operate Lock" message:changeToMessage preferredStyle:UIAlertControllerStyleAlert];
    [changeAlertController addAction:[UIAlertAction actionWithTitle:@"Change" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [characteristic writeValue:[NSNumber numberWithInteger:targetState]
                 completionHandler:^(NSError *error) {
                     if (error) {
                         NSLog(@"Error changing state: %@",error.localizedDescription);
                     } else {
                         [self.tableView reloadData];
                     }
                 }];
    }]];
    [changeAlertController addAction:[UIAlertAction actionWithTitle:@"Don't Change" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:changeAlertController animated:YES completion:nil];
}

- (void)handlePowerTransitionForCharacteristic:(HMCharacteristic *)characteristic {
    NSString *changeToState = @"";
    BOOL targetState = NO;
    
    if ([characteristic.value boolValue] == NO) {
        changeToState = @"On";
        targetState = YES;
    }
    if ([characteristic.value boolValue] == YES) {
        changeToState = @"Off";
        targetState = NO;
    }
    NSString *changeToMessage = [NSString stringWithFormat:@"Change to %@?",changeToState];
    
    UIAlertController *changeAlertController = [UIAlertController alertControllerWithTitle:@"Operate Light" message:changeToMessage preferredStyle:UIAlertControllerStyleAlert];
    [changeAlertController addAction:[UIAlertAction actionWithTitle:@"Change" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        [characteristic writeValue:[NSNumber numberWithBool:targetState]
                 completionHandler:^(NSError *error) {
                     if (error) {
                         NSLog(@"Error changing state: %@",error.localizedDescription);
                     } else {
                         [self.tableView reloadData];
                     }
         }];
    }]];
    [changeAlertController addAction:[UIAlertAction actionWithTitle:@"Don't Change" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:changeAlertController animated:YES completion:nil];
    
    //For Action Set info
    HMActionSet *turnOnLightsActionSet = nil;
    
    [self.home addActionSetWithName:@"Turn On Lights"
                  completionHandler:^(HMActionSet *actionSet, NSError *error) {
        if (!error) {
            
            HMCharacteristicWriteAction *writeAction =
            [[HMCharacteristicWriteAction alloc] initWithCharacteristic:characteristic
            targetValue:[NSNumber numberWithBool:YES]];
            
            [actionSet addAction:writeAction completionHandler:^(NSError *error) {
                if (error) {
                    NSLog(@"Error adding action to actionSet: %@", error.localizedDescription);
                }
            }];
        }
    }];
    
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"roomSelectionSegue"]) {
        ICFAccessoryRoomSelectionTableViewController *accRoomSelectionVC = (ICFAccessoryRoomSelectionTableViewController *)segue.destinationViewController;
        [accRoomSelectionVC setAccessory:self.detailAccessory];
        [accRoomSelectionVC setHome:self.home];
    }
}

#pragma mark - Translation and Formatting
- (NSString *)characteristicInfoForCharacteristic:(HMCharacteristic *)characteristic {
    NSString *characteristicInfo = [[self humanReadableCharacteristics] objectForKey:characteristic.characteristicType];
    characteristicInfo = [characteristicInfo stringByAppendingString:@"- "];
    
    //Specific Cases
    if ([characteristic.characteristicType isEqualToString:HMCharacteristicTypeCurrentLockMechanismState] ||
        [characteristic.characteristicType isEqualToString:HMCharacteristicTypeTargetLockMechanismState]) {
        characteristicInfo = [characteristicInfo stringByAppendingString:[self humanReadableLockStateForState:[characteristic.value integerValue]]];
        return characteristicInfo;
    }
    
    if ([characteristic.characteristicType isEqualToString:HMCharacteristicTypePowerState]) {
        NSString *powerState = [characteristic.value boolValue] ? @"ON" : @"OFF";
        characteristicInfo = [characteristicInfo stringByAppendingString:powerState];
        return characteristicInfo;
    }
    
    //General Cases
    if (characteristic.value) {
        if ([characteristic.value isKindOfClass:[NSString class]]) {
            characteristicInfo = [characteristicInfo stringByAppendingString:characteristic.value];
        } else if (![characteristic.value isKindOfClass:[NSNull class]]) {
            characteristicInfo = [characteristicInfo stringByAppendingString:[characteristic.value stringValue]];
        }
    }
    return characteristicInfo;
}

- (NSString *)propertyInfoForCharacteristic:(HMCharacteristic *)characteristic {
    NSString *propertyType = @"Property is (";
    NSString *extraSpace = @"";
    for (NSString *property in characteristic.properties) {
        propertyType = [propertyType stringByAppendingString:extraSpace];
        if ([property isEqualToString:HMCharacteristicPropertyWritable]) {
            propertyType = [propertyType stringByAppendingString:@"writable"];
            extraSpace = @" ";
        }
        if ([property isEqualToString:HMCharacteristicPropertyReadable]) {
            propertyType = [propertyType stringByAppendingString:@"readable"];
            extraSpace = @" ";
        }
        if ([property isEqualToString:HMCharacteristicPropertySupportsEventNotification]) {
            propertyType = [propertyType stringByAppendingString:@"notification"];
            extraSpace = @" ";
        }
    }
    propertyType = [propertyType stringByAppendingString:@")"];
    return propertyType;
}

- (NSDictionary *)humanReadableCharacteristics {
    return @{ HMCharacteristicTypePowerState : @"Power State",
              HMCharacteristicTypeHue : @"Hue",
              HMCharacteristicTypeSaturation : @"Saturation",
              HMCharacteristicTypeBrightness : @"Brightness",
              HMCharacteristicTypeTemperatureUnits : @"Temp Units",
              HMCharacteristicTypeCurrentTemperature : @"Current Temp",
              HMCharacteristicTypeTargetTemperature : @"Target Temp",
              HMCharacteristicTypeCoolingThreshold : @"Cool Threshold",
              HMCharacteristicTypeHeatingThreshold : @"Heat Threshold",
              HMCharacteristicTypeCurrentRelativeHumidity : @"Current Humidity",
              HMCharacteristicTypeTargetRelativeHumidity : @"Target Humidity",
              HMCharacteristicTypeCurrentDoorState : @"Current Door State",
              HMCharacteristicTypeTargetDoorState : @"Target Door State",
              HMCharacteristicTypeObstructionDetected : @"Obstruction Detected",
              HMCharacteristicTypeName : @"Name",
              HMCharacteristicTypeManufacturer : @"Manufacturer",
              HMCharacteristicTypeModel : @"Model",
              HMCharacteristicTypeSerialNumber : @"Serial Number",
              HMCharacteristicTypeIdentify : @"Identify",
              HMCharacteristicTypeRotationDirection : @"Rotation Direction",
              HMCharacteristicTypeRotationSpeed : @"Rotation Speed",
              HMCharacteristicTypeOutletInUse : @"Outlet In Use",
              HMCharacteristicTypeVersion : @"Version",
              HMCharacteristicTypeLogs : @"Logs",
              HMCharacteristicTypeAudioFeedback : @"Audio Feedback",
              HMCharacteristicTypeAdminOnlyAccess : @"Admin Only Access",
              HMCharacteristicTypeMotionDetected : @"Motion Detected",
              HMCharacteristicTypeCurrentLockMechanismState : @"Current Lock State",
              HMCharacteristicTypeTargetLockMechanismState : @"Target Lock State",
              HMCharacteristicTypeLockMechanismLastKnownAction : @"Lock Last Action",
              HMCharacteristicTypeLockManagementControlPoint : @"Control Point",
              HMCharacteristicTypeLockManagementAutoSecureTimeout : @"Auto Secure Timeout"
             };
}

- (NSString *)humanReadableLockStateForState:(HMCharacteristicValueLockMechanismState)state {
    NSString *humanReadableLockState = @"Unknown";
    switch (state) {
        case HMCharacteristicValueLockMechanismStateJammed:
            humanReadableLockState = @"Jammed";
            break;
        case HMCharacteristicValueLockMechanismStateSecured:
            humanReadableLockState = @"Locked";
            break;
        case HMCharacteristicValueLockMechanismStateUnknown:
            humanReadableLockState = @"Unknown";
            break;
        case HMCharacteristicValueLockMechanismStateUnsecured:
            humanReadableLockState = @"Unlocked";
            break;
            
        default:
            break;
    }
    return humanReadableLockState;
}

@end

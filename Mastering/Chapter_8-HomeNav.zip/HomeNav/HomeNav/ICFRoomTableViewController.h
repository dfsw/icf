//
//  ICFRoomTableViewController.h
//  HomeNav
//
//  Created by Joe Keeley on 12/7/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import HomeKit;

@interface ICFRoomTableViewController : UITableViewController

@property (nonatomic, strong) HMHome *home;

@end

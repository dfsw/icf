//
//  ICFHomeTableViewCell.m
//  HomeNav
//
//  Created by Joe Keeley on 11/23/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFHomeTableViewCell.h"

@implementation ICFHomeTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

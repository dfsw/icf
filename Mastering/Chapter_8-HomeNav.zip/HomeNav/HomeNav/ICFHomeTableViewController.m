//
//  ICFHomeTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 11/23/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFHomeTableViewController.h"
@import HomeKit;
#import "ICFHomeTableViewCell.h"
#import "ICFHomeInfoTableViewController.h"

@interface ICFHomeTableViewController () <HMHomeManagerDelegate>

@property (nonatomic, strong) HMHomeManager *homeManager;
- (IBAction)addHomeButtonTapped:(id)sender;

@end

@implementation ICFHomeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.homeManager = [[HMHomeManager alloc] init];
    [self.homeManager setDelegate:self];
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated {
    [self.tableView reloadData];
}

#pragma mark - Actions
- (IBAction)addHomeButtonTapped:(id)sender {
    UIAlertController *addHomeAlertController = [UIAlertController alertControllerWithTitle:@"Add Home" message:@"Specify a name for your home - Siri will be able to use what you provide to refer to your home." preferredStyle:UIAlertControllerStyleAlert];
    [addHomeAlertController addAction:[UIAlertAction actionWithTitle:@"Add Home" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField *homeNameTextField = addHomeAlertController.textFields.firstObject;
        NSString *newHomeName = homeNameTextField.text;
        __weak ICFHomeTableViewController *weakSelf = self;
        [self.homeManager addHomeWithName:newHomeName completionHandler:^(HMHome *home, NSError *error)
        {
            if (error)
            {
                NSLog(@"Error adding home: %@",error.localizedDescription);
            } else
            {
                NSInteger rowForAddedHome = [weakSelf.homeManager.homes indexOfObject:home];
                
                NSIndexPath *indexPathForAddedHome =
                [NSIndexPath indexPathForRow:rowForAddedHome inSection:0];
                
                [weakSelf.tableView insertRowsAtIndexPaths:@[indexPathForAddedHome]
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }];
    }]];
    [addHomeAlertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [addHomeAlertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        [textField setPlaceholder:@"New Home Name..."];
    }];
    [self presentViewController:addHomeAlertController animated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.homeManager.homes count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ICFHomeTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ICFHomeTableViewCell" forIndexPath:indexPath];
    
    HMHome *home = self.homeManager.homes[indexPath.row];
    
    [cell.homeNameLabel setText:home.name];
    
    NSString *roomPlural = ([home.rooms count] == 1) ? @"" : @"s";
    NSString *roomCount =
    [NSString stringWithFormat:@"%lu room%@",
     (unsigned long)[home.rooms count],roomPlural];
    
    [cell.roomCountLabel setText:roomCount];
    
    NSString *accPlural = ([home.accessories count] == 1) ? @"y" : @"ies";
    NSString *accessoriesCount =
    [NSString stringWithFormat:@"%lu accessor%@",
     (unsigned long)[home.accessories count],accPlural];
    
    [cell.accessoriesCountLabel setText:accessoriesCount];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        HMHome *homeToRemove = [self.homeManager.homes objectAtIndex:indexPath.row];
        __weak ICFHomeTableViewController *weakSelf = self;

        [self.homeManager removeHome:homeToRemove completionHandler:^(NSError *error) {
            
            [weakSelf.tableView deleteRowsAtIndexPaths:@[indexPath]
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            
        }];
    }
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ICFHomeInfoTableViewController *homeInfoVC = (ICFHomeInfoTableViewController *)segue.destinationViewController;
    NSIndexPath *indexPath = [self.tableView indexPathForCell:sender];
    [homeInfoVC setHome:[self.homeManager.homes objectAtIndex:indexPath.row]];
}

#pragma mark - Home Manager Delegate
- (void)homeManagerDidUpdateHomes:(HMHomeManager *)manager {
    [self.tableView reloadData];
    
    if ([manager.homes count] == 0)
    {
        [self addHomeButtonTapped:nil];
    }
}

- (void)homeManager:(HMHomeManager *)manager didAddHome:(HMHome *)home {
    NSInteger rowForAddedHome = [manager.homes indexOfObject:home];
    
    NSIndexPath *indexPathForAddedHome =
    [NSIndexPath indexPathForRow:rowForAddedHome inSection:0];
    
    [self.tableView insertRowsAtIndexPaths:@[indexPathForAddedHome]
                          withRowAnimation:UITableViewRowAnimationAutomatic];
}

- (void)homeManager:(HMHomeManager *)manager didRemoveHome:(HMHome *)home {
    NSInteger rowForRemovedHome = [manager.homes indexOfObject:home];
    
    NSIndexPath *indexPathForRemovedHome =
    [NSIndexPath indexPathForRow:rowForRemovedHome inSection:0];
    
    [self.tableView deleteRowsAtIndexPaths:@[indexPathForRemovedHome]
                          withRowAnimation:UITableViewRowAnimationAutomatic];

    if ([manager.homes count] == 0)
    {
        [self addHomeButtonTapped:nil];
    }
}

@end

//
//  ICFRoomTableViewController.m
//  HomeNav
//
//  Created by Joe Keeley on 12/7/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFRoomTableViewController.h"

@interface ICFRoomTableViewController ()

@end

@implementation ICFRoomTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewDidAppear:(BOOL)animated {
    if ([self.home.rooms count] == 0) {
        [self addRoom];
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.home.rooms count] + 1;
}


- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"roomNameCell"
                                                            forIndexPath:indexPath];
    
    if (indexPath.row == 0)
    {
        [cell.textLabel setText:@"Tap to add new room"];
    } else
    {
        NSInteger row = indexPath.row - 1;
        HMRoom *room = [self.home.rooms objectAtIndex:row];
        [cell.textLabel setText:room.name];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        [self addRoom];
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return UITableViewCellEditingStyleInsert;
    } else {
        return UITableViewCellEditingStyleDelete;
    }
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        HMRoom *roomToDelete = [self.home.rooms objectAtIndex:(indexPath.row - 1)];
        [self.home removeRoom:roomToDelete completionHandler:^(NSError *error) {
            [tableView deleteRowsAtIndexPaths:@[indexPath]
                             withRowAnimation:UITableViewRowAnimationAutomatic];
        }];
    }
    if (editingStyle == UITableViewCellEditingStyleInsert) {
        [self addRoom];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    return [[UIView alloc] init];
}

- (void)addRoom {
    UIAlertController *addRoomAlertController = [UIAlertController alertControllerWithTitle:@"Add Room" message:@"Specify a name for a new room - Siri will be able to use what you provide to refer to your room." preferredStyle:UIAlertControllerStyleAlert];
    [addRoomAlertController addAction:[UIAlertAction actionWithTitle:@"Add Room" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        UITextField *roomNameTextField = addRoomAlertController.textFields.firstObject;
        NSString *newRoomName = roomNameTextField.text;
        
        __weak ICFRoomTableViewController *weakSelf = self;
        [self.home addRoomWithName:newRoomName completionHandler:^(HMRoom *room, NSError *error)
        {
            if (error)
            {
                NSLog(@"Error adding home: %@",error.localizedDescription);
            } else
            {
                NSInteger row = [weakSelf.home.rooms indexOfObject:room];
                NSIndexPath *addedRoomIndexPath = [NSIndexPath indexPathForRow:(row + 1) inSection:0];
                [weakSelf.tableView insertRowsAtIndexPaths:@[addedRoomIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
            }
        }];
    }]];
    [addRoomAlertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [addRoomAlertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        [textField setPlaceholder:@"New Room Name..."];
    }];
    [self presentViewController:addRoomAlertController animated:YES completion:nil];

}

@end

//
//  ICFAssetViewController.h
//  PhotoLibrary
//
//  Created by Joe Keeley on 8/6/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import Photos;

@interface ICFAssetViewController : UIViewController

@property (nonatomic, strong) PHAsset *asset;
@property (nonatomic, weak) IBOutlet UIImageView *assetImageView;
- (IBAction)deleteButtonTapped:(id)sender;

@end

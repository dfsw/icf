//
//  ICFAlbumCollectionViewController.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 9/8/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAlbumCollectionViewController.h"
#import "ICFAssetCollectionViewCell.h"
#import "ICFAssetViewController.h"

@interface ICFAlbumCollectionViewController () <UIImagePickerControllerDelegate, UINavigationControllerDelegate, PHPhotoLibraryChangeObserver>
@property (nonatomic, strong) PHFetchResult *assetResult;

@end

@implementation ICFAlbumCollectionViewController

static NSString * const reuseIdentifier = @"assetCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.assetResult = [PHAsset fetchAssetsInAssetCollection:self.selectedCollection options:nil];
    [self setTitle:[self.selectedCollection localizedTitle]];
    
    BOOL cameraAvailable = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
    [self.addPhotoButton setEnabled:cameraAvailable];
}

- (void)viewWillAppear:(BOOL)animated {
    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showImage"]) {
        ICFAssetViewController *controller = (ICFAssetViewController *)segue.destinationViewController;
        
        NSIndexPath *indexPath = [self.collectionView indexPathsForSelectedItems][0];
        controller.asset = self.assetResult[indexPath.row];
    }
}


#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return 1;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.assetResult.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    ICFAssetCollectionViewCell *cell = (ICFAssetCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    // Configure the cell
    PHAsset *assetForCell = [self.assetResult objectAtIndex:indexPath.row];
    PHImageManager *imageManager = [PHImageManager defaultManager];
    [imageManager requestImageForAsset:assetForCell
                            targetSize:CGSizeMake(50, 50)
                           contentMode:PHImageContentModeAspectFill
                               options:nil
                         resultHandler:^(UIImage *result, NSDictionary *info){
                             [cell.assetImageView setImage:result];
                             [cell setNeedsLayout];
                         }];
    
    return cell;
}

#pragma mark - add photo button tapped
- (IBAction)addPhotoButtonTapped:(id)sender {
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        UIImagePickerController *picker = [[UIImagePickerController alloc] init];
        [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
        [picker setDelegate:self];
        [self presentViewController:picker animated:YES completion:^{}];
    }

}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    UIImage *selectedImage = [info objectForKey:UIImagePickerControllerOriginalImage];
    [self dismissViewControllerAnimated:YES
                             completion:^{}];
    
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        
        PHAssetChangeRequest *addImageRequest =
        [PHAssetChangeRequest creationRequestForAssetFromImage:selectedImage];
        
        PHObjectPlaceholder *addedImagePlaceholder =
        [addImageRequest placeholderForCreatedAsset];
        
        PHAssetCollectionChangeRequest *addImageToAlbum =
        [PHAssetCollectionChangeRequest changeRequestForAssetCollection:self.selectedCollection];

        [addImageToAlbum addAssets:@[addedImagePlaceholder]];
    } completionHandler:^(BOOL success, NSError *error) {
        if (!success) {
            NSLog(@"Error creating new asset: %@", error.localizedDescription);
        }
    }];
}

#pragma mark - PHPhotoLibraryChangeObserver
- (void)photoLibraryDidChange:(PHChange *)changeInstance {
    dispatch_async(dispatch_get_main_queue(), ^{
        
        PHFetchResultChangeDetails *changesToFetchResult =
        [changeInstance changeDetailsForFetchResult:self.assetResult];
        
        if (changesToFetchResult)
        {
            self.assetResult = [changesToFetchResult fetchResultAfterChanges];
            
            if ([changesToFetchResult hasIncrementalChanges]) {
                NSMutableArray *indexPathsToInsert = [[NSMutableArray alloc] init];

                [[changesToFetchResult insertedIndexes]
                 enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
                     
                    NSIndexPath *indexPathToInsert =
                     [NSIndexPath indexPathForRow:idx inSection:0];
                     
                    [indexPathsToInsert addObject:indexPathToInsert];
                     
                }];
                
                [self.collectionView insertItemsAtIndexPaths:indexPathsToInsert];
            }
        }
    });
}

@end

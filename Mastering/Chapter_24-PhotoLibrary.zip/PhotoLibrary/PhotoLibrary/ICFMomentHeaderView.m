//
//  ICFMomentHeaderView.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 9/10/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFMomentHeaderView.h"

@implementation ICFMomentHeaderView

@end

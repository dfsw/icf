//
//  ICFAlbumTableViewController.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 8/6/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAlbumTableViewController.h"
#import "ICFAlbumCollectionViewController.h"
@import Photos;

@interface ICFAlbumTableViewController () <PHPhotoLibraryChangeObserver>

@property (nonatomic, strong) PHFetchResult *albumsFetchResult;

- (IBAction)addAlbumButtonTapped:(id)sender;

@end

@implementation ICFAlbumTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.albumsFetchResult =
    [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum
                                             subtype:PHAssetCollectionSubtypeAny
                                             options:nil];
    
    self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated {
    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];
}

- (void)viewWillDisappear:(BOOL)animated {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

- (IBAction)addAlbumButtonTapped:(id)sender {
    UIAlertController *addAlbumAlertController = [UIAlertController alertControllerWithTitle:@"Add Album" message:@"" preferredStyle:UIAlertControllerStyleAlert];
    [addAlbumAlertController addAction:[UIAlertAction actionWithTitle:@"Add Album" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {

        UITextField *albumNameTextField = addAlbumAlertController.textFields.firstObject;
        NSString *newAlbumName = albumNameTextField.text;
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:newAlbumName];
        } completionHandler:^(BOOL success, NSError *error) {
            if (!success) {
                NSLog(@"Error encountered adding album: %@",error.localizedDescription);
            }
        }];
    }]];
    [addAlbumAlertController addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    [addAlbumAlertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        [textField setPlaceholder:@"New Album Name..."];
    }];
    [self presentViewController:addAlbumAlertController animated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.albumsFetchResult.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"albumTableCell" forIndexPath:indexPath];
    
    PHAssetCollection *album =
    [self.albumsFetchResult objectAtIndex:indexPath.row];

    [cell.textLabel setText:album.localizedTitle];

    if (album.estimatedAssetCount != NSNotFound)
    {
        NSString *albumPlural = album.estimatedAssetCount > 1 ? @"s" : @"";
        
        NSString *subTitle =
        [NSString stringWithFormat:@"%lu Photo%@",
         (unsigned long)album.estimatedAssetCount, albumPlural];
        
        [cell.detailTextLabel setText:subTitle];
        
    } else
    {
        [cell.detailTextLabel setText:@"-- empty --"];
    }
    
    PHFetchResult *albumMoments = [PHAsset fetchKeyAssetsInAssetCollection:album options:nil];
    PHAsset *firstAsset = [albumMoments firstObject];
    
    PHImageManager *imageManager = [PHImageManager defaultManager];
    [imageManager requestImageForAsset:firstAsset
                            targetSize:CGSizeMake(80, 80)
                           contentMode:PHImageContentModeAspectFill
                               options:nil
                         resultHandler:^(UIImage *result, NSDictionary *info){
                             [cell.imageView setImage:result];
                             [cell setNeedsLayout];
                         }];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        PHAssetCollection *albumToBeDeleted =
        [self.albumsFetchResult objectAtIndex:indexPath.row];
        
        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
            [PHAssetCollectionChangeRequest deleteAssetCollections:@[albumToBeDeleted]];
        } completionHandler:^(BOOL success, NSError *error) {
            if (!success) {
                NSLog(@"Error encountered adding album: %@",error.localizedDescription);
            }
        }];
    }
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showAlbum"]) {
        
        ICFAlbumCollectionViewController *controller =
        (ICFAlbumCollectionViewController *)segue.destinationViewController;
        
        NSIndexPath *tappedPath = [self.tableView indexPathForSelectedRow];
        
        PHAssetCollection *tappedCollection =
        [self.albumsFetchResult objectAtIndex:tappedPath.row];
        
        [controller setSelectedCollection:tappedCollection];
    }
}

#pragma mark - PHPhotoLibraryChangeObserver

- (void)photoLibraryDidChange:(PHChange *)changeInstance {
    dispatch_async(dispatch_get_main_queue(), ^{
        
        PHFetchResultChangeDetails *changesToFetchResult =
        [changeInstance changeDetailsForFetchResult:self.albumsFetchResult];
        
        self.albumsFetchResult = [changesToFetchResult fetchResultAfterChanges];
        
        if ([changesToFetchResult hasIncrementalChanges]) {
            [self.tableView beginUpdates];
            
            [[changesToFetchResult removedIndexes]
             enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
                 
                NSIndexPath *indexPathToRemove = [NSIndexPath indexPathForRow:idx inSection:0];
                
                [self.tableView deleteRowsAtIndexPaths:@[indexPathToRemove]
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }];
            
            [[changesToFetchResult insertedIndexes]
             enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
                 
                NSIndexPath *indexPathToInsert = [NSIndexPath indexPathForRow:idx inSection:0];
                
                [self.tableView insertRowsAtIndexPaths:@[indexPathToInsert]
                                      withRowAnimation:UITableViewRowAnimationAutomatic];
            }];
            
            [self.tableView endUpdates];
            
        }
    });
}

@end

//
//  ICFPhotosCollectionViewController.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 11/9/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFPhotosCollectionViewController.h"
#import "ICFPhotosCollectionViewCell.h"
#import "ICFMomentHeaderView.h"
#import "ICFAssetViewController.h"

@interface ICFPhotosCollectionViewController () <PHPhotoLibraryChangeObserver>
@property (nonatomic, strong) PHFetchResult *collectionResult;
@property (nonatomic, strong) NSMutableArray *collectionAssetResults;
@property (nonatomic, strong) NSDateFormatter *momentDateFormatter;
@end

@implementation ICFPhotosCollectionViewController

static NSString * const reuseIdentifier = @"photoCell";
static NSString * const headerReuseIdentifier = @"momentHeader";

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.momentDateFormatter = [[NSDateFormatter alloc] init];
    [self.momentDateFormatter setDateStyle:NSDateFormatterMediumStyle];
    [self.momentDateFormatter setTimeStyle:NSDateFormatterNoStyle];

    [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus status) {
        if (status == PHAuthorizationStatusAuthorized) {
            [self loadAssetCollectionsForDisplay];
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertController *notAuthorizedAlert = [UIAlertController alertControllerWithTitle:@"Not Authorized" message:@"You have denied access to your photos.  Please visit Settings | Privacy | Photos to grant access to the photos for this app." preferredStyle:UIAlertControllerStyleAlert];
                [notAuthorizedAlert addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleCancel handler:nil]];
                [self presentViewController:notAuthorizedAlert animated:YES completion:nil];
            });
        }
    }];
}

- (void)dealloc {
    [[PHPhotoLibrary sharedPhotoLibrary] unregisterChangeObserver:self];
}

- (void)loadAssetCollectionsForDisplay {
    [[PHPhotoLibrary sharedPhotoLibrary] registerChangeObserver:self];

    PHFetchOptions *options = [[PHFetchOptions alloc] init];
    options.sortDescriptors = @[[NSSortDescriptor sortDescriptorWithKey:@"startDate"
                                                              ascending:YES]];
    
    self.collectionResult =
    [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeMoment
                                             subtype:PHAssetCollectionSubtypeAny
                                             options:options];
    
    self.collectionAssetResults =
    [[NSMutableArray alloc] initWithCapacity:self.collectionResult.count];
    
    for (PHAssetCollection *collection in self.collectionResult) {
        PHFetchResult *result = [PHAsset fetchAssetsInAssetCollection:collection
                                                              options:nil];
        [self.collectionAssetResults insertObject:result
                                          atIndex:[self.collectionResult indexOfObject:collection]];
    }
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.collectionView reloadData];
    });
}

#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"showImage"]) {
        
        ICFAssetViewController *controller =
        (ICFAssetViewController *)segue.destinationViewController;
        
        NSIndexPath *indexPath = [self.collectionView indexPathsForSelectedItems][0];
        PHFetchResult *result = self.collectionAssetResults[indexPath.section];
        controller.asset = result[indexPath.row];
    }
}

#pragma mark <UICollectionViewDataSource>

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView {
    return self.collectionResult.count;
}


- (NSInteger)collectionView:(UICollectionView *)collectionView
     numberOfItemsInSection:(NSInteger)section {
    
    PHFetchResult *result =
    (PHFetchResult *)[self.collectionAssetResults objectAtIndex:section];
    
    return result.count;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionReusableView *supplementaryView = nil;
    
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        
        ICFMomentHeaderView *headerView =
        [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                           withReuseIdentifier:headerReuseIdentifier
                                                  forIndexPath:indexPath];
        
        PHAssetCollection *moment = [self.collectionResult objectAtIndex:indexPath.section];

        [headerView.titleLabel setText:
         [NSString stringWithFormat:@"%@ - %@",
          [self.momentDateFormatter stringFromDate:moment.startDate],
          [self.momentDateFormatter stringFromDate:moment.endDate]]];

        [headerView.subTitleLabel setText:moment.localizedTitle];

        supplementaryView = headerView;
    }
    
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
    }
    
    return supplementaryView;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {

    ICFPhotosCollectionViewCell *cell = (ICFPhotosCollectionViewCell *)[collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier forIndexPath:indexPath];
    
    PHFetchResult *result = self.collectionAssetResults[indexPath.section];
    PHAsset *asset = result[indexPath.row];
    
    PHImageManager *imageManager = [PHImageManager defaultManager];
    [imageManager requestImageForAsset:asset
                            targetSize:CGSizeMake(50, 50)
                           contentMode:PHImageContentModeAspectFill
                               options:nil
                         resultHandler:^(UIImage *result, NSDictionary *info){
                             [cell.assetImageView setImage:result];
                             [cell setNeedsLayout];
                         }];
    
    return cell;
}

#pragma mark - PHPhotoLibraryChangeObserver
- (void)photoLibraryDidChange:(PHChange *)changeInstance {
    dispatch_async(dispatch_get_main_queue(), ^{
        
        for (PHFetchResult *fetchResult in self.collectionAssetResults) {
            PHFetchResultChangeDetails *changesToFetchResult = [changeInstance changeDetailsForFetchResult:fetchResult];
            if (changesToFetchResult && [changesToFetchResult hasIncrementalChanges]) {
                NSUInteger sectionIndex = [self.collectionAssetResults indexOfObject:fetchResult];
                [self.collectionAssetResults replaceObjectAtIndex:sectionIndex withObject:[changesToFetchResult fetchResultAfterChanges]];

                NSMutableArray *indexPathsToRemove = [[NSMutableArray alloc] init];
                [[changesToFetchResult removedIndexes] enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
                    NSIndexPath *indexPathToRemove = [NSIndexPath indexPathForRow:idx inSection:sectionIndex];
                    [indexPathsToRemove addObject:indexPathToRemove];
                }];
                NSMutableArray *indexPathsToInsert = [[NSMutableArray alloc] init];
                [[changesToFetchResult insertedIndexes] enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL *stop) {
                    NSIndexPath *indexPathToInsert = [NSIndexPath indexPathForRow:idx inSection:sectionIndex];
                    [indexPathsToInsert addObject:indexPathToInsert];
                }];

                [self.collectionView performBatchUpdates:^{
                    [self.collectionView deleteItemsAtIndexPaths:indexPathsToRemove];
                    [self.collectionView insertItemsAtIndexPaths:indexPathsToInsert];
                } completion:^(BOOL finished) {
                    //
                }];
            }
        }
    });
}


@end

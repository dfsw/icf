//
//  ICFPhotosCollectionViewCell.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 11/9/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFPhotosCollectionViewCell.h"

@implementation ICFPhotosCollectionViewCell

@end

//
//  ICFPhotosCollectionViewController.h
//  PhotoLibrary
//
//  Created by Joe Keeley on 11/9/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import Photos;

@interface ICFPhotosCollectionViewController : UICollectionViewController

@property (nonatomic, strong) PHAssetCollection *selectedCollection;

@end

//
//  ICFAlbumCollectionViewController.h
//  PhotoLibrary
//
//  Created by Joe Keeley on 9/8/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
@import Photos;

@interface ICFAlbumCollectionViewController : UICollectionViewController

@property (nonatomic, strong) PHAssetCollection *selectedCollection;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *addPhotoButton;
- (IBAction)addPhotoButtonTapped:(id)sender;

@end

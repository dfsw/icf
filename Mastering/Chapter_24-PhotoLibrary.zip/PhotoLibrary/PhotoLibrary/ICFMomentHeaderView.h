//
//  ICFMomentHeaderView.h
//  PhotoLibrary
//
//  Created by Joe Keeley on 9/10/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFMomentHeaderView : UICollectionReusableView
@property (nonatomic, weak) IBOutlet UILabel *titleLabel;
@property (nonatomic, weak) IBOutlet UILabel *subTitleLabel;
@property (nonatomic, weak) IBOutlet UIButton *shareButton;

@end

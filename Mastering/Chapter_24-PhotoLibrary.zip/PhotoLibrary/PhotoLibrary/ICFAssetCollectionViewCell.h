//
//  ICFAssetCollectionViewCell.h
//  PhotoLibrary
//
//  Created by Joe Keeley on 9/8/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAssetCollectionViewCell : UICollectionViewCell

@property (nonatomic, weak) IBOutlet UIImageView *assetImageView;

@end

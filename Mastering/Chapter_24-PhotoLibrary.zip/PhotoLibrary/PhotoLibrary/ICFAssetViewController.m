//
//  ICFAssetViewController.m
//  PhotoLibrary
//
//  Created by Joe Keeley on 8/6/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFAssetViewController.h"

@interface ICFAssetViewController ()

@end

@implementation ICFAssetViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    PHImageManager *imageManager = [PHImageManager defaultManager];
    [imageManager requestImageForAsset:self.asset
                            targetSize:self.assetImageView.bounds.size
                           contentMode:PHImageContentModeAspectFit
                               options:nil
                         resultHandler:^(UIImage *result, NSDictionary *info){
                             [self.assetImageView setImage:result];
                             [self.assetImageView setNeedsLayout];
                         }];

}

- (IBAction)deleteButtonTapped:(id)sender {
    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
        [PHAssetChangeRequest deleteAssets:@[self.asset]];
    } completionHandler:^(BOOL success, NSError *error) {
        if (success) {
            [self.navigationController popViewControllerAnimated:YES];
        } else {
            NSLog(@"Error deleting asset: %@",error.localizedDescription);
        }
    }];
}

@end

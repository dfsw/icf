//
//  ICFAppDelegate.m
//  SocialNetworking
//
//  Created by Kyle Richter on 9/1/12.
//  Copyright (c) 2012 Kyle Richter. All rights reserved.
//

#import "ICFAppDelegate.h"

#import "ICFViewController.h"

@implementation ICFAppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    self.viewController = [[ICFViewController alloc] initWithNibName:@"ICFViewController" bundle:nil];
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    return YES;
}


@end

//
//  ICFAppDelegate.h
//  SocialNetworking
//
//  Created by Kyle Richter on 9/1/12.
//  Copyright (c) 2012 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ICFViewController;

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ICFViewController *viewController;

@end

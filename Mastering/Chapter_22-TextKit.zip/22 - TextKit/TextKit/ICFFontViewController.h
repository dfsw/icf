//
//  ICFFontViewController.h
//  TextKit
//
//  Created by Kyle Richter on 7/13/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFFontViewController : UIViewController
{
    IBOutlet UITextView *myTextView; 
    
}
@end

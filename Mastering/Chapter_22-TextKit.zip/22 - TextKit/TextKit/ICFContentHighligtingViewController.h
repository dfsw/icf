//
//  ICFContentHighligtingViewController.h
//  TextKit
//
//  Created by Kyle Richter on 7/21/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFContentHighligtingViewController : UIViewController
{
    
    UITextView *myTextView;
    
}

@end

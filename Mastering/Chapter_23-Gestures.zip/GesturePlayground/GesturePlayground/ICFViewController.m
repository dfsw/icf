//
//  ICFViewController.m
//  GesturePlayground
//
//  Created by Joe Keeley on 8/1/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import "ICFViewController.h"

@interface ICFViewController ()

@end

@implementation ICFViewController

#pragma mark - UIGestureRecognizerDelegate methods
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}


#pragma mark - UIGestureRecognizer handling methods
- (IBAction)myGestureViewTapped:(UIGestureRecognizer *)tapGestureRecognizer
{
    UIAlertController *alert =
    [UIAlertController alertControllerWithTitle:@"Tap Received"
                                        message:@"Received tap in myGestureView"
                                 preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *dismissAction =
    [UIAlertAction actionWithTitle:@"OK, Thanks"
                             style:UIAlertActionStyleCancel
                           handler:^(UIAlertAction *action){
        [self dismissViewControllerAnimated:YES completion:nil];
    }];
    
    [alert addAction:dismissAction];
    
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)myGestureViewSingleTapped:(UIGestureRecognizer *)tapGestureRecognizer {
    NSLog(@"Single Tap Received");
}

- (void)myGestureViewDoubleTapped:(UIGestureRecognizer *)doubleTapGestureRecognizer {
    NSLog(@"Double Tap Received");
}

- (void)myGestureViewSoloPinched:(UIPinchGestureRecognizer *)pinchGesture {
    CGFloat pinchScale = [pinchGesture scale];
    
    CGAffineTransform scaleTransform = 	CGAffineTransformMakeScale(pinchScale, pinchScale);
    
    [self.myGestureView setTransform:scaleTransform];
}

- (void)updateViewTransformWithScaleDelta:(CGFloat)scaleDelta andRotationDelta:(CGFloat)rotationDelta;
{
    if (rotationDelta != 0) {
        [self setCurrentRotationDelta:rotationDelta];
    }
    if (scaleDelta != 0) {
        [self setCurrentScaleDelta:scaleDelta];
    }
    CGFloat scaleAmount = [self scaleFactor]+[self currentScaleDelta];
    CGAffineTransform scaleTransform = CGAffineTransformMakeScale(scaleAmount, scaleAmount);
    
    CGFloat rotationAmount = [self rotationFactor]+[self currentRotationDelta];
    CGAffineTransform rotateTransform = CGAffineTransformMakeRotation(rotationAmount);
    
    CGAffineTransform newTransform = CGAffineTransformConcat(scaleTransform, rotateTransform);
    [self.myGestureView setTransform:newTransform];
}

- (void)myGestureViewPinched:(UIPinchGestureRecognizer *)pinchGesture {
    CGFloat newPinchDelta = [pinchGesture scale] - 1; //scale starts at 1.0
    [self updateViewTransformWithScaleDelta:newPinchDelta andRotationDelta:0];
    if ([pinchGesture state] == UIGestureRecognizerStateEnded) {
        [self setScaleFactor:[self scaleFactor] + newPinchDelta];
        [self setCurrentScaleDelta:0.0];
    }
}

- (void)myGestureViewRotated:(UIRotationGestureRecognizer *)rotateGesture {
    CGFloat newRotateRadians = [rotateGesture rotation];
    
    [self updateViewTransformWithScaleDelta:0.0 andRotationDelta:newRotateRadians];
    if ([rotateGesture state] == UIGestureRecognizerStateEnded) {
        CGFloat saveRotation = [self rotationFactor] + newRotateRadians;
        [self setRotationFactor:saveRotation];
        [self setCurrentRotationDelta:0.0];
    }
}

- (void)clearAllGestureRecognizers {
    [self.myGestureView setGestureRecognizers:@[]];
    [self.view setGestureRecognizers:@[]];
    
    [self.myGestureView setTransform:CGAffineTransformIdentity];
}


- (IBAction)setUpTapGestureRecognizer:(id)sender {
    [self clearAllGestureRecognizers];

    UITapGestureRecognizer *tapRecognizer =
    [[UITapGestureRecognizer alloc] initWithTarget:self
                                            action:@selector(myGestureViewTapped:)];

    [self.myGestureView addGestureRecognizer:tapRecognizer];
}

- (IBAction)setUpPinchGestureRecognizerOnMyGestureView:(id)sender {
    [self clearAllGestureRecognizers];
    
    UIPinchGestureRecognizer *soloPinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewSoloPinched:)];
    [self.myGestureView addGestureRecognizer:soloPinchRecognizer];
}

- (IBAction)setUpPinchGestureRecognizerOnMainView:(id)sender {
    [self clearAllGestureRecognizers];
    UIPinchGestureRecognizer *soloPinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewSoloPinched:)];
    [[self view] addGestureRecognizer:soloPinchRecognizer];
}

- (IBAction)setUpPinchAndRotationGestureRecognizers:(id)sender {
    [self clearAllGestureRecognizers];
    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewPinched:)];
    [self.myGestureView addGestureRecognizer:pinchRecognizer];
    
    UIRotationGestureRecognizer *rotateRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewRotated:)];
    [self.myGestureView addGestureRecognizer:rotateRecognizer];

    //set defaults for scale and rotation
    [self setScaleFactor:1.0];
    [self setRotationFactor:0.0];
}

- (IBAction)setUpPinchAndRotationGestureRecognizersWithDelegate:(id)sender {
    [self clearAllGestureRecognizers];
    UIPinchGestureRecognizer *pinchRecognizer = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewPinched:)];
    [pinchRecognizer setDelegate:self];
    [self.myGestureView addGestureRecognizer:pinchRecognizer];
    
    UIRotationGestureRecognizer *rotateRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewRotated:)];
    [rotateRecognizer setDelegate:self];
    [self.myGestureView addGestureRecognizer:rotateRecognizer];
    
    //set defaults for scale and rotation
    [self setScaleFactor:1.0];
    [self setRotationFactor:0.0];
}

- (IBAction)setUpSingleAndDoubleTapGestureRecognizers:(id)sender {
    [self clearAllGestureRecognizers];
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewDoubleTapped:)];
    [doubleTapRecognizer setNumberOfTapsRequired:2];
    [self.myGestureView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *singleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewSingleTapped:)];
    [self.myGestureView addGestureRecognizer:singleTapRecognizer];

}

- (IBAction)setUpSingleAndDoubleTapGestureRecognizersWithFail:(id)sender {
    [self clearAllGestureRecognizers];
    UITapGestureRecognizer *doubleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewDoubleTapped:)];
    [doubleTapRecognizer setNumberOfTapsRequired:2];
    [self.myGestureView addGestureRecognizer:doubleTapRecognizer];
    
    UITapGestureRecognizer *singleTapRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myGestureViewSingleTapped:)];
    [singleTapRecognizer requireGestureRecognizerToFail:doubleTapRecognizer];
    [self.myGestureView addGestureRecognizer:singleTapRecognizer];
    
}

@end

//
//  ICFViewController.h
//  GesturePlayground
//
//  Created by Joe Keeley on 8/1/14.
//  Copyright (c) 2014 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFViewController : UIViewController <UIGestureRecognizerDelegate>

@property (weak, nonatomic) IBOutlet UIView *myGestureView;

@property (nonatomic, assign) CGFloat scaleFactor;
@property (nonatomic, assign) CGFloat rotationFactor;
@property (nonatomic, assign) CGFloat currentScaleDelta;
@property (nonatomic, assign) CGFloat currentRotationDelta;

- (void)myGestureViewTapped:(UIGestureRecognizer *)tapGesture;
- (void)myGestureViewPinched:(UIPinchGestureRecognizer *)pinchGesture;
- (void)myGestureViewRotated:(UIRotationGestureRecognizer *)rotateGesture;

@end
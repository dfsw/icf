//
//  main.m
//  player
//
//  Created by Kyle Richter on 3/2/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ICFAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ICFAppDelegate class]));
    }
}

//
//  PHGSectionFooter.m
//  PhotoGallery
//
//  Created by Joe Keeley on 7/19/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import "PHGSectionFooter.h"

@implementation PHGSectionFooter

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end

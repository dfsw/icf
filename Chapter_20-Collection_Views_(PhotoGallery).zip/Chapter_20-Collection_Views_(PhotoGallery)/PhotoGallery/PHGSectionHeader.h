//
//  PHGSectionHeader.h
//  PhotoGallery
//
//  Created by Joe Keeley on 7/5/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGSectionHeader : UICollectionReusableView

@property (nonatomic, retain) IBOutlet UILabel *headerLabel;

@end

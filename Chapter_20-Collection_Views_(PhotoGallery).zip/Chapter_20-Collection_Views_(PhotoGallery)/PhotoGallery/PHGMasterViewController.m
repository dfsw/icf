//
//  PHGMasterViewController.m
//  PhotoGallery
//
//  Created by Joe Keeley on 6/4/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import "PHGMasterViewController.h"

@interface PHGMasterViewController () {
    NSMutableArray *_objects;
}
@end

@implementation PHGMasterViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




@end

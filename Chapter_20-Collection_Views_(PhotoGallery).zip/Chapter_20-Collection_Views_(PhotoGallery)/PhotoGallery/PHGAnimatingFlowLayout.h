//
//  PHGAnimatingFlowLayout.h
//  PhotoGallery
//
//  Created by Joe Keeley on 7/22/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGAnimatingFlowLayout : UICollectionViewFlowLayout

@end

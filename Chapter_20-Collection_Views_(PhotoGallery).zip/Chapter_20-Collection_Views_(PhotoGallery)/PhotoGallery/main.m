//
//  main.m
//  PhotoGallery
//
//  Created by Joe Keeley on 6/4/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PHGAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PHGAppDelegate class]));
    }
}

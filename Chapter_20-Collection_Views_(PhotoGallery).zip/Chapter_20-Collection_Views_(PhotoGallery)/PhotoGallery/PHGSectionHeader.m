//
//  PHGSectionHeader.m
//  PhotoGallery
//
//  Created by Joe Keeley on 7/5/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import "PHGSectionHeader.h"

@implementation PHGSectionHeader

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

@end

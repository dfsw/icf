//
//  main.m
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/10/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ICFAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ICFAppDelegate class]));
    }
}

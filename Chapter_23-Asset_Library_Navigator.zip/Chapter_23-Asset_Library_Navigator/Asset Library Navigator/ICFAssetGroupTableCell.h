//
//  ICFAssetGroupTableCell.h
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/15/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAssetGroupTableCell : UITableViewCell

@property (nonatomic, retain) IBOutlet UIImageView *assetImageView1;
@property (nonatomic, retain) IBOutlet UIImageView *assetImageView2;
@property (nonatomic, retain) IBOutlet UIImageView *assetImageView3;
@property (nonatomic, retain) IBOutlet UIImageView *assetImageView4;

@property (nonatomic, retain) IBOutlet UIButton *assetButton1;
@property (nonatomic, retain) IBOutlet UIButton *assetButton2;
@property (nonatomic, retain) IBOutlet UIButton *assetButton3;
@property (nonatomic, retain) IBOutlet UIButton *assetButton4;

@end

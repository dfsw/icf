//
//  ICFAssetViewController.h
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/15/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAssetViewController : UIViewController

@property (nonatomic, retain) IBOutlet UIImageView *assetImageView;
@property (nonatomic, retain) UIImage *assetImage;

@end

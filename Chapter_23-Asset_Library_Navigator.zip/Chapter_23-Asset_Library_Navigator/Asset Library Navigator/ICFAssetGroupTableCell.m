//
//  ICFAssetGroupTableCell.m
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/15/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import "ICFAssetGroupTableCell.h"

@implementation ICFAssetGroupTableCell

@synthesize assetImageView1;
@synthesize assetImageView2;
@synthesize assetImageView3;
@synthesize assetImageView4;

@synthesize assetButton1;
@synthesize assetButton2;
@synthesize assetButton3;
@synthesize assetButton4;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

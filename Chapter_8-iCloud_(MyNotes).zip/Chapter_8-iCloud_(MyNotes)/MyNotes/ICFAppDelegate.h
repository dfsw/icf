//
//  ICFAppDelegate.h
//  MyNotes
//
//  Created by Joe Keeley on 6/26/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

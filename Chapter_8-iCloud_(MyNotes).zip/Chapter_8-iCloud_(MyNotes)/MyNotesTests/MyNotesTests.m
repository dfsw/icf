//
//  MyNotesTests.m
//  MyNotesTests
//
//  Created by Joe Keeley on 6/26/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface MyNotesTests : XCTestCase

@end

@implementation MyNotesTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end

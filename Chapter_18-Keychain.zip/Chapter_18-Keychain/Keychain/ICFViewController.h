//
//  ICFViewController.h
//  Keychain
//
//  Created by Kyle Richter on 4/28/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KeychainItemWrapper.h"

@interface ICFViewController : UIViewController <UIAlertViewDelegate>
{

    UITextField *pinField;
    UITextField *pinFieldRepeat;
    KeychainItemWrapper *pinWrapper;
    IBOutlet UITextField *numberTextField;
    IBOutlet UITextField *expDateTextField;
    IBOutlet UITextField *CV2CodeTextField;
    IBOutlet UITextField *nameTextField;
}

- (IBAction)save:(id)sender;

@end

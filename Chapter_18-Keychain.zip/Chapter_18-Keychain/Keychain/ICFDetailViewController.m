//
//  ICFDetailViewController.m
//  Keychain
//
//  Created by Kyle Richter on 5/5/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import "ICFDetailViewController.h"

@interface ICFDetailViewController ()

@end

@implementation ICFDetailViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

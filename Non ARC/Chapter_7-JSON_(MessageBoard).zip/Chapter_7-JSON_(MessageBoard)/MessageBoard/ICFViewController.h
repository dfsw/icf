//
//  ICFViewController.h
//  MessageBoard
//
//  Created by Joe Keeley on 3/29/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, retain) NSMutableData *connectionData;
@property (nonatomic, retain) NSArray *messageArray;
@property (retain, nonatomic) IBOutlet UITableView *messageTable;
@property (retain, nonatomic) IBOutlet UIView *activityView;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

- (IBAction)newMessageTouched:(id)sender;

@end

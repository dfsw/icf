//
//  ICFNewMessageViewController.h
//  MessageBoard
//
//  Created by Joe Keeley on 3/30/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFNewMessageViewController : UIViewController <UITextFieldDelegate, UITextViewDelegate>

@property (retain, nonatomic) IBOutlet UITextField *nameTextField;
@property (retain, nonatomic) IBOutlet UITextView *messageTextView;
@property (nonatomic, retain) NSMutableData *connectionData;
@property (retain, nonatomic) IBOutlet UIView *activityView;
@property (retain, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

- (IBAction)cancelButtonTouched:(id)sender;
- (IBAction)saveButtonTouched:(id)sender;

@end

//
//  ICFOperationQueueCustomViewController.h
//  LongRunningTasks
//
//  Created by Joe Keeley on 9/1/12.
//  Copyright (c) 2012 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICFCustomOperation.h"

@interface ICFOperationQueueCustomViewController : UITableViewController <ICFCustomOperationDelegate>

@property (nonatomic, retain) NSMutableArray *displayItems;
@property (nonatomic, retain) NSOperationQueue *processingQueue;
@property (nonatomic, retain) IBOutlet UIView *statusView;

- (IBAction)cancelButtonTouched:(id)sender;

@end

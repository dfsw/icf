//
//  ICFExculsionPathViewController.h
//  TextKit
//
//  Created by Kyle Richter on 7/14/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFExculsionPathViewController : UIViewController

@property (retain, nonatomic) IBOutlet UITextView *myTextView;

@end

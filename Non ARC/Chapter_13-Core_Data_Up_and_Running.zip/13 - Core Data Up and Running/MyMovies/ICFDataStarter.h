//
//  ICFDataStarter.h
//  MyMovies
//
//  Created by Joe Keeley on 6/25/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ICFDataStarter : NSObject

+ (void)setupStarterData;

@end

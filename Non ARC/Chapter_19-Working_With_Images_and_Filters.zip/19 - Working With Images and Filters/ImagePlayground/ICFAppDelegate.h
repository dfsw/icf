//
//  ICFAppDelegate.h
//  ImagePlayground
//
//  Created by Joe Keeley on 11/3/12.
//  Copyright (c) 2012 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@end

//
//  ICFDetailViewController.h
//  Keychain
//
//  Created by Kyle Richter on 5/5/13.
//  Copyright (c) 2013 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFDetailViewController : UIViewController

@end

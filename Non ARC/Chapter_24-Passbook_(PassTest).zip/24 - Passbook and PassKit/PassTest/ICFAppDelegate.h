//
//  ICFAppDelegate.h
//  PassTest
//
//  Created by Joe Keeley on 7/26/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAppDelegate : UIResponder <UIApplicationDelegate>

@property (retain, nonatomic) UIWindow *window;

@end

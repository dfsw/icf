//
//  ICFTimeLineCell.m
//  SocialNetworking
//
//  Created by Kyle Richter on 12/4/12.
//  Copyright (c) 2012 Kyle Richter. All rights reserved.
//

#import "ICFTimeLineCell.h"

@implementation ICFTimeLineCell
@synthesize avatarImageView;
@synthesize timelineTextLabel;


- (void)dealloc
{
    [avatarImageView release];
    [timelineTextLabel release];
    [super dealloc];
}

@end

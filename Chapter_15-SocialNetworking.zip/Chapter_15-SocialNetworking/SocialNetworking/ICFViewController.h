//
//  ICFViewController.h
//  SocialNetworking
//
//  Created by Kyle Richter on 9/1/12.
//  Copyright (c) 2012 Kyle Richter. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "social/Social.h"
#import "accounts/Accounts.h"


@interface ICFViewController : UIViewController <UITextViewDelegate, UIActionSheetDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate>
{
    
    IBOutlet UITextView *socialTextView;
    IBOutlet UILabel *charCountLabel;
    
    ACAccount *facebookAccount;
    
    UIImage *attachmentImage;
    UIImagePickerController *picker;

}

@property(nonatomic, retain) UIImage *attachmentImage;
@property(nonatomic, retain) ACAccount *facebookAccount;

- (IBAction)facebookAction:(id)sender;
- (IBAction)twitterAction:(id)sender;
- (IBAction)attachImage:(id)sender;

@end

class Shout < ActiveRecord::Base
end

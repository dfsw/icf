module ShoutsHelper
end

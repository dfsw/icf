require 'test_helper'

class ShoutsHelperTest < ActionView::TestCase
end

# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
IcfShoutOutServer::Application.initialize!

require 'apn_on_rails'


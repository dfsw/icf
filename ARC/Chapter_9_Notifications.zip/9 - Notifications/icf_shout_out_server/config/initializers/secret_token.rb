# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
IcfShoutOutServer::Application.config.secret_token = 'b49d0d234f57e86ec14d9424cc9e05d5589846eec554493a1ef24e7e7a878f13a0a64a903c71a2f5d77acb3bbc3dbd03282d39fe56426012db528a9519c1c87a'

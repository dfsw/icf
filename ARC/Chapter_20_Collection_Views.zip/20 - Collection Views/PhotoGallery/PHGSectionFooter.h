//
//  PHGSectionFooter.h
//  PhotoGallery
//
//  Created by Joe Keeley on 7/19/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PHGSectionFooter : UICollectionReusableView

@property (nonatomic, retain) IBOutlet UILabel *footerLabel;

@end

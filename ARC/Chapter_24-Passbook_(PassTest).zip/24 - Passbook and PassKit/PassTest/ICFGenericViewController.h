//
//  ICFGenericViewController.h
//  PassTest
//
//  Created by Joe Keeley on 9/9/12.
//  Copyright (c) 2012 Joe Keeley. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ICFPassViewController.h"

@interface ICFGenericViewController : ICFPassViewController

@end

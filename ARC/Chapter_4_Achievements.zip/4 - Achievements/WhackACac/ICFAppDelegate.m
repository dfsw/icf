//
//  ICFAppDelegate.m
//  WhackACac
//
//  Created by Kyle Richter on 7/2/12.
//  Copyright (c) 2012 Dragon Forged Software. All rights reserved.
//

#import "ICFAppDelegate.h"

#import "ICFViewController.h"

@implementation ICFAppDelegate

@synthesize window = _window;
@synthesize navController = _navController;
@synthesize viewController = _viewController;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    self.viewController = [[ICFViewController alloc] initWithNibName:@"ICFViewController" bundle:nil];
    
    self.navController = [[UINavigationController alloc] initWithRootViewController:self.viewController];
    
    [self.navController setNavigationBarHidden: YES];
    
    self.window.rootViewController = self.navController
    ;
    [self.window makeKeyAndVisible];
    return YES;
}


@end

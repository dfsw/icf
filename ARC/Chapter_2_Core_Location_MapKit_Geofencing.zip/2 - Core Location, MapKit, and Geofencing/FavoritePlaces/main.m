//
//  main.m
//  FavoritePlaces
//
//  Created by Joe Keeley on 1/21/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ICFAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ICFAppDelegate class]));
    }
}

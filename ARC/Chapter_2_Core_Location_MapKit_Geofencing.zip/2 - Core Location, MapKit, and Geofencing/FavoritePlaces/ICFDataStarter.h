//
//  ICFDataStarter.h
//  FavoritePlaces
//
//  Created by Joe Keeley on 1/25/13.
//  Copyright (c) 2013 ICF. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ICFDataStarter : NSObject

+ (void)setupStarterData;

@end

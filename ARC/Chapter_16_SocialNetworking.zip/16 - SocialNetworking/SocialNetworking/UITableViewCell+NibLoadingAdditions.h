#import <Foundation/Foundation.h>


@interface UITableViewCell (NibLoadingAdditions) 

+ (UITableViewCell *) cellFromNib:(NSString *) nibName;

@end

//
//  ICFViewController.h
//  MessageBoard
//
//  Created by Joe Keeley on 3/29/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) NSMutableData *connectionData;
@property (nonatomic, strong) NSArray *messageArray;
@property (strong, nonatomic) IBOutlet UITableView *messageTable;
@property (strong, nonatomic) IBOutlet UIView *activityView;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

- (IBAction)newMessageTouched:(id)sender;

@end

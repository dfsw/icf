//
//  ICFNewMessageViewController.h
//  MessageBoard
//
//  Created by Joe Keeley on 3/30/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFNewMessageViewController : UIViewController <UITextFieldDelegate, UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UITextField *nameTextField;
@property (strong, nonatomic) IBOutlet UITextView *messageTextView;
@property (nonatomic, strong) NSMutableData *connectionData;
@property (strong, nonatomic) IBOutlet UIView *activityView;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

- (IBAction)cancelButtonTouched:(id)sender;
- (IBAction)saveButtonTouched:(id)sender;

@end

//
//  ICFAssetLibraryViewController.h
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/15/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAssetLibraryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UIAlertViewDelegate>

@property (nonatomic, strong) NSArray *assetGroupArray;
@property (nonatomic, strong) IBOutlet UITableView *assetGroupTableView;
@property (nonatomic, strong) NSURL *selectedGroupURL;

- (void)setupAssetData;

@end

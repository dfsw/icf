//
//  ICFAssetViewController.h
//  Asset Library Navigator
//
//  Created by Joe Keeley on 4/15/12.
//  Copyright (c) 2012 Explore Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ICFAssetViewController : UIViewController

@property (nonatomic, strong) IBOutlet UIImageView *assetImageView;
@property (nonatomic, strong) UIImage *assetImage;

@end
